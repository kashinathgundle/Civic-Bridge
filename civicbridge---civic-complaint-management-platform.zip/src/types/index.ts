export type Role = 'citizen' | 'official' | 'admin';

export type ComplaintStatus =
  | 'submitted'
  | 'under_review'
  | 'assigned'
  | 'in_progress'
  | 'resolved'
  | 'rejected';

export type Priority = 'low' | 'medium' | 'high' | 'critical';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  phone?: string;
  departmentId?: string;
  wardId?: string;
  avatarUrl?: string;
  createdAt: string;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  contactEmail: string;
  phone: string;
  headName: string;
}

export interface Ward {
  id: string;
  number: number;
  name: string;
  zone: string;
  councillor: string;
  centerLat: number;
  centerLng: number;
}

export interface Category {
  id: string;
  name: string;
  code: string;
  departmentId: string;
  departmentName: string;
  iconName: string;
  description: string;
  defaultPriority: Priority;
  slaHours: number;
}

export interface TimelineEvent {
  id: string;
  status: ComplaintStatus;
  title: string;
  actorName: string;
  actorRole: Role;
  timestamp: string;
  remarks?: string;
  attachmentUrl?: string;
}

export interface AiSuggestion {
  categoryId: string;
  categoryName: string;
  confidence: number; // 0 to 1
  suggestedPriority: Priority;
  matchedKeywords: string[];
  reasoning: string;
  engine: 'local_rule_nlp' | 'custom';
}

export interface Complaint {
  id: string; // e.g., CB-2026-4891
  title: string;
  description: string;
  categoryId: string;
  categoryName: string;
  departmentId: string;
  departmentName: string;
  wardId: string;
  wardName: string;
  priority: Priority;
  status: ComplaintStatus;
  
  // Citizen Details
  citizenId: string;
  citizenName: string;
  citizenEmail: string;
  citizenPhone: string;

  // Location
  address: string;
  coordinates: {
    lat: number;
    lng: number;
  };

  // Media
  photos: string[];
  resolutionPhoto?: string;

  // Assignment & Resolution
  assignedOfficialId?: string;
  assignedOfficialName?: string;
  assignedTeam?: string;
  officialRemarks?: string;
  resolutionRemarks?: string;
  rejectionReason?: string;
  citizenRating?: number; // 1 to 5
  citizenFeedback?: string;

  // AI Tagging
  aiSuggestion?: AiSuggestion;

  // Timeline & Timestamps
  timeline: TimelineEvent[];
  createdAt: string;
  updatedAt: string;
  resolvedAt?: string;
}

export interface NotificationItem {
  id: string;
  userId?: string;
  roleTarget?: Role | 'all';
  complaintId?: string;
  title: string;
  message: string;
  type: 'status_update' | 'new_complaint' | 'assignment' | 'alert';
  isRead: boolean;
  createdAt: string;
}

export interface DashboardStats {
  total: number;
  submitted: number;
  underReview: number;
  assigned: number;
  inProgress: number;
  resolved: number;
  rejected: number;
  critical: number;
  highPriority: number;
  avgResolutionHours: number;
  resolutionRatePercent: number;
}
