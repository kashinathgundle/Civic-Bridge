import {
  Category,
  Complaint,
  ComplaintStatus,
  DashboardStats,
  Department,
  NotificationItem,
  Priority,
  Role,
  TimelineEvent,
  User,
  Ward
} from '../types';
import {
  DEMO_USERS,
  INITIAL_CATEGORIES,
  INITIAL_COMPLAINTS,
  INITIAL_DEPARTMENTS,
  INITIAL_NOTIFICATIONS,
  INITIAL_WARDS
} from '../data/seedData';
import JSZip from 'jszip';

const STORAGE_KEYS = {
  USERS: 'civicbridge_users_v1',
  COMPLAINTS: 'civicbridge_complaints_v1',
  CATEGORIES: 'civicbridge_categories_v1',
  DEPARTMENTS: 'civicbridge_departments_v1',
  WARDS: 'civicbridge_wards_v1',
  NOTIFICATIONS: 'civicbridge_notifications_v1',
  CURRENT_USER: 'civicbridge_active_user_v1'
};

function safeGet<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) return fallback;
    return JSON.parse(item) as T;
  } catch (e) {
    console.warn(`[CivicBridge Storage] Failed to read ${key}:`, e);
    return fallback;
  }
}

function safeSet<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn(`[CivicBridge Storage] Failed to write ${key}:`, e);
  }
}

export class StorageService {
  private static instance: StorageService;

  private constructor() {
    this.initializeIfEmpty();
  }

  public static getInstance(): StorageService {
    if (!StorageService.instance) {
      StorageService.instance = new StorageService();
    }
    return StorageService.instance;
  }

  public initializeIfEmpty(): void {
    if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
      safeSet(STORAGE_KEYS.USERS, DEMO_USERS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.DEPARTMENTS)) {
      safeSet(STORAGE_KEYS.DEPARTMENTS, INITIAL_DEPARTMENTS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.WARDS)) {
      safeSet(STORAGE_KEYS.WARDS, INITIAL_WARDS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.CATEGORIES)) {
      safeSet(STORAGE_KEYS.CATEGORIES, INITIAL_CATEGORIES);
    }
    if (!localStorage.getItem(STORAGE_KEYS.COMPLAINTS)) {
      safeSet(STORAGE_KEYS.COMPLAINTS, INITIAL_COMPLAINTS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS)) {
      safeSet(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.CURRENT_USER)) {
      // Default to citizen user for fresh demo visit
      safeSet(STORAGE_KEYS.CURRENT_USER, DEMO_USERS[0]);
    }
  }

  public resetAllToSeed(): void {
    safeSet(STORAGE_KEYS.USERS, DEMO_USERS);
    safeSet(STORAGE_KEYS.DEPARTMENTS, INITIAL_DEPARTMENTS);
    safeSet(STORAGE_KEYS.WARDS, INITIAL_WARDS);
    safeSet(STORAGE_KEYS.CATEGORIES, INITIAL_CATEGORIES);
    safeSet(STORAGE_KEYS.COMPLAINTS, INITIAL_COMPLAINTS);
    safeSet(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    safeSet(STORAGE_KEYS.CURRENT_USER, DEMO_USERS[0]);
  }

  // --- Auth & Users ---
  public getUsers(): User[] {
    return safeGet<User[]>(STORAGE_KEYS.USERS, DEMO_USERS);
  }

  public getCurrentUser(): User {
    const fallback = DEMO_USERS[0];
    return safeGet<User>(STORAGE_KEYS.CURRENT_USER, fallback);
  }

  public setCurrentUser(user: User): void {
    safeSet(STORAGE_KEYS.CURRENT_USER, user);
  }

  public registerUser(name: string, email: string, role: Role = 'citizen', phone?: string, wardId?: string): User {
    const users = this.getUsers();
    const existing = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      throw new Error(`An account with email ${email} already exists.`);
    }

    const newUser: User = {
      id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      name: name.trim(),
      email: email.trim().toLowerCase(),
      role,
      phone: phone?.trim(),
      wardId: wardId || 'ward_101',
      avatarUrl: `https://images.unsplash.com/photo-${1534528741775 + (users.length % 5)}?w=150&auto=format&fit=crop&q=80`,
      createdAt: new Date().toISOString()
    };

    users.push(newUser);
    safeSet(STORAGE_KEYS.USERS, users);
    this.setCurrentUser(newUser);

    this.addNotification({
      roleTarget: 'all',
      title: 'New Citizen Registered',
      message: `${newUser.name} registered on the CivicBridge portal.`,
      type: 'alert'
    });

    return newUser;
  }

  public loginUser(email: string): User | null {
    const users = this.getUsers();
    const found = users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
    if (found) {
      this.setCurrentUser(found);
      return found;
    }
    return null;
  }

  public updateUserRole(userId: string, role: Role, departmentId?: string, wardId?: string): void {
    const users = this.getUsers();
    const idx = users.findIndex(u => u.id === userId);
    if (idx !== -1) {
      users[idx] = {
        ...users[idx],
        role,
        departmentId: departmentId ?? users[idx].departmentId,
        wardId: wardId ?? users[idx].wardId
      };
      safeSet(STORAGE_KEYS.USERS, users);

      const active = this.getCurrentUser();
      if (active.id === userId) {
        this.setCurrentUser(users[idx]);
      }
    }
  }

  // --- Departments, Wards & Categories ---
  public getDepartments(): Department[] {
    return safeGet<Department[]>(STORAGE_KEYS.DEPARTMENTS, INITIAL_DEPARTMENTS);
  }

  public saveDepartment(department: Department): void {
    const depts = this.getDepartments();
    const idx = depts.findIndex(d => d.id === department.id);
    if (idx >= 0) {
      depts[idx] = department;
    } else {
      depts.push(department);
    }
    safeSet(STORAGE_KEYS.DEPARTMENTS, depts);
  }

  public getWards(): Ward[] {
    return safeGet<Ward[]>(STORAGE_KEYS.WARDS, INITIAL_WARDS);
  }

  public saveWard(ward: Ward): void {
    const wards = this.getWards();
    const idx = wards.findIndex(w => w.id === ward.id);
    if (idx >= 0) {
      wards[idx] = ward;
    } else {
      wards.push(ward);
    }
    safeSet(STORAGE_KEYS.WARDS, wards);
  }

  public getCategories(): Category[] {
    return safeGet<Category[]>(STORAGE_KEYS.CATEGORIES, INITIAL_CATEGORIES);
  }

  public saveCategory(category: Category): void {
    const cats = this.getCategories();
    const idx = cats.findIndex(c => c.id === category.id);
    if (idx >= 0) {
      cats[idx] = category;
    } else {
      cats.push(category);
    }
    safeSet(STORAGE_KEYS.CATEGORIES, cats);
  }

  // --- Complaints ---
  public getComplaints(): Complaint[] {
    return safeGet<Complaint[]>(STORAGE_KEYS.COMPLAINTS, INITIAL_COMPLAINTS);
  }

  public getComplaintById(id: string): Complaint | undefined {
    return this.getComplaints().find(c => c.id === id);
  }

  public generateComplaintId(): string {
    const complaints = this.getComplaints();
    const nextNum = 1000 + complaints.length + Math.floor(Math.random() * 89);
    return `CB-2026-${nextNum}`;
  }

  public createComplaint(data: Omit<Complaint, 'id' | 'createdAt' | 'updatedAt' | 'timeline' | 'status'> & { initialRemarks?: string }): Complaint {
    const complaints = this.getComplaints();
    const id = this.generateComplaintId();
    const now = new Date().toISOString();

    const initialTimeline: TimelineEvent = {
      id: `tl_${id}_init`,
      status: 'submitted',
      title: 'Complaint Registered by Citizen',
      actorName: data.citizenName,
      actorRole: 'citizen',
      timestamp: now,
      remarks: data.initialRemarks || 'Filed via CivicBridge web platform.'
    };

    const newComplaint: Complaint = {
      ...data,
      id,
      status: 'submitted',
      timeline: [initialTimeline],
      createdAt: now,
      updatedAt: now
    };

    complaints.unshift(newComplaint);
    safeSet(STORAGE_KEYS.COMPLAINTS, complaints);

    // Create notifications for officials and admin
    this.addNotification({
      roleTarget: 'official',
      complaintId: id,
      title: `New Issue: ${data.categoryName}`,
      message: `${id} reported in ${data.wardName}: "${data.title.substring(0, 50)}..."`,
      type: 'new_complaint'
    });

    this.addNotification({
      roleTarget: 'admin',
      complaintId: id,
      title: `New Grievance Logged: ${id}`,
      message: `Priority: ${data.priority.toUpperCase()} | Department: ${data.departmentName}`,
      type: 'new_complaint'
    });

    return newComplaint;
  }

  public updateComplaintStatus(
    complaintId: string,
    status: ComplaintStatus,
    options: {
      actorName: string;
      actorRole: Role;
      remarks?: string;
      assignedOfficialId?: string;
      assignedOfficialName?: string;
      assignedTeam?: string;
      resolutionPhoto?: string;
      rejectionReason?: string;
    }
  ): Complaint {
    const complaints = this.getComplaints();
    const idx = complaints.findIndex(c => c.id === complaintId);
    if (idx === -1) {
      throw new Error(`Complaint ${complaintId} not found.`);
    }

    const complaint = complaints[idx];
    const now = new Date().toISOString();

    const titleMap: Record<ComplaintStatus, string> = {
      submitted: 'Complaint Re-opened',
      under_review: 'Under Official Review',
      assigned: 'Assigned to Field Team',
      in_progress: 'Maintenance Work In Progress',
      resolved: 'Complaint Marked Resolved',
      rejected: 'Complaint Closed / Rejected'
    };

    const newTimelineEvent: TimelineEvent = {
      id: `tl_${complaintId}_${Date.now()}`,
      status,
      title: titleMap[status] || `Status updated to ${status}`,
      actorName: options.actorName,
      actorRole: options.actorRole,
      timestamp: now,
      remarks: options.remarks,
      attachmentUrl: options.resolutionPhoto
    };

    const updated: Complaint = {
      ...complaint,
      status,
      updatedAt: now,
      timeline: [...complaint.timeline, newTimelineEvent],
      assignedOfficialId: options.assignedOfficialId ?? complaint.assignedOfficialId,
      assignedOfficialName: options.assignedOfficialName ?? complaint.assignedOfficialName,
      assignedTeam: options.assignedTeam ?? complaint.assignedTeam,
      officialRemarks: options.remarks ?? complaint.officialRemarks,
      resolutionPhoto: options.resolutionPhoto ?? complaint.resolutionPhoto,
      resolutionRemarks: status === 'resolved' ? (options.remarks ?? complaint.resolutionRemarks) : complaint.resolutionRemarks,
      resolvedAt: status === 'resolved' ? now : complaint.resolvedAt,
      rejectionReason: status === 'rejected' ? (options.rejectionReason || options.remarks) : complaint.rejectionReason
    };

    complaints[idx] = updated;
    safeSet(STORAGE_KEYS.COMPLAINTS, complaints);

    // Notify citizen
    this.addNotification({
      userId: complaint.citizenId,
      roleTarget: 'citizen',
      complaintId,
      title: `Update on ${complaintId}: ${status.replace('_', ' ').toUpperCase()}`,
      message: options.remarks || `Your grievance status was updated to ${status.replace('_', ' ')}.`,
      type: 'status_update'
    });

    return updated;
  }

  public addCitizenFeedback(complaintId: string, rating: number, feedback?: string): void {
    const complaints = this.getComplaints();
    const idx = complaints.findIndex(c => c.id === complaintId);
    if (idx !== -1) {
      complaints[idx].citizenRating = rating;
      complaints[idx].citizenFeedback = feedback;
      safeSet(STORAGE_KEYS.COMPLAINTS, complaints);
    }
  }

  // --- Notifications ---
  public getNotifications(role?: Role, userId?: string): NotificationItem[] {
    const all = safeGet<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    if (!role && !userId) return all;

    return all.filter(n => {
      if (n.userId && userId && n.userId === userId) return true;
      if (n.roleTarget === 'all') return true;
      if (role && n.roleTarget === role) return true;
      return false;
    });
  }

  public addNotification(item: Omit<NotificationItem, 'id' | 'createdAt' | 'isRead'>): NotificationItem {
    const list = safeGet<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    const newItem: NotificationItem = {
      ...item,
      id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
      isRead: false
    };
    list.unshift(newItem);
    safeSet(STORAGE_KEYS.NOTIFICATIONS, list.slice(0, 100)); // retain last 100
    return newItem;
  }

  public markNotificationAsRead(id: string): void {
    const list = safeGet<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    const item = list.find(n => n.id === id);
    if (item) {
      item.isRead = true;
      safeSet(STORAGE_KEYS.NOTIFICATIONS, list);
    }
  }

  public markAllNotificationsAsRead(): void {
    const list = safeGet<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    list.forEach(n => {
      n.isRead = true;
    });
    safeSet(STORAGE_KEYS.NOTIFICATIONS, list);
  }

  // --- Analytics & Statistics ---
  public getStats(): DashboardStats {
    const complaints = this.getComplaints();
    const total = complaints.length;
    const submitted = complaints.filter(c => c.status === 'submitted').length;
    const underReview = complaints.filter(c => c.status === 'under_review').length;
    const assigned = complaints.filter(c => c.status === 'assigned').length;
    const inProgress = complaints.filter(c => c.status === 'in_progress').length;
    const resolved = complaints.filter(c => c.status === 'resolved').length;
    const rejected = complaints.filter(c => c.status === 'rejected').length;
    const critical = complaints.filter(c => c.priority === 'critical').length;
    const highPriority = complaints.filter(c => c.priority === 'high').length;

    // Calculate average resolution time for resolved complaints
    const resolvedComplaints = complaints.filter(c => c.status === 'resolved' && c.resolvedAt);
    let totalDurationMs = 0;
    for (const c of resolvedComplaints) {
      const created = new Date(c.createdAt).getTime();
      const resolvedTime = new Date(c.resolvedAt!).getTime();
      totalDurationMs += Math.max(0, resolvedTime - created);
    }

    const avgResolutionHours = resolvedComplaints.length > 0
      ? Math.round((totalDurationMs / (resolvedComplaints.length * 3600 * 1000)) * 10) / 10
      : 32.5;

    const resolutionRatePercent = total > 0 ? Math.round((resolved / total) * 100) : 0;

    return {
      total,
      submitted,
      underReview,
      assigned,
      inProgress,
      resolved,
      rejected,
      critical,
      highPriority,
      avgResolutionHours,
      resolutionRatePercent
    };
  }

  // --- CSV Export ---
  public exportComplaintsToCsv(): void {
    const complaints = this.getComplaints();
    const headers = [
      'Complaint ID',
      'Title',
      'Category',
      'Department',
      'Ward',
      'Priority',
      'Status',
      'Citizen Name',
      'Citizen Contact',
      'Address',
      'Latitude',
      'Longitude',
      'Assigned Official',
      'Field Team',
      'Created At',
      'Last Updated',
      'Resolved At',
      'Citizen Rating'
    ];

    const escapeCsv = (val: string | number | undefined | null) => {
      if (val === undefined || val === null) return '""';
      const str = String(val).replace(/"/g, '""');
      return `"${str}"`;
    };

    const rows = complaints.map(c => [
      escapeCsv(c.id),
      escapeCsv(c.title),
      escapeCsv(c.categoryName),
      escapeCsv(c.departmentName),
      escapeCsv(c.wardName),
      escapeCsv(c.priority.toUpperCase()),
      escapeCsv(c.status.replace('_', ' ').toUpperCase()),
      escapeCsv(c.citizenName),
      escapeCsv(c.citizenPhone || c.citizenEmail),
      escapeCsv(c.address),
      escapeCsv(c.coordinates?.lat),
      escapeCsv(c.coordinates?.lng),
      escapeCsv(c.assignedOfficialName || 'Unassigned'),
      escapeCsv(c.assignedTeam || 'None'),
      escapeCsv(c.createdAt),
      escapeCsv(c.updatedAt),
      escapeCsv(c.resolvedAt || 'N/A'),
      escapeCsv(c.citizenRating ? `${c.citizenRating} / 5` : 'Pending')
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `CivicBridge_Complaints_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  // --- Project Source Export (ZIP for College Presentation) ---
  public async exportProjectZip(): Promise<void> {
    const zip = new JSZip();

    // Add README with setup and architecture instructions
    const readmeContent = `# CivicBridge - AI-Powered Civic Complaint Management Platform

A modern, responsive, open-source civic grievance redresal application built for college engineering project evaluation.

## 🚀 Key Highlights & Features
1. **Zero-Cost Operation**: Operates 100% free with no paid APIs, no Google Maps billing, and no paid hosting required.
2. **Autonomous Rule-Based AI Engine**: Local Natural Language Processing classifier that categorizes complaints, evaluates urgency, and extracts key municipal hazard tokens with zero external API latency or cost.
3. **Interactive OpenStreetMap + Leaflet**: Free geographic mapping and location pin dropper with reverse-geocoded coordinates and manual address entry.
4. **Three Distinct Roles & Dashboards**:
   - **Citizen**: File issues with photo proof, track live audit timeline, rate resolution quality.
   - **Municipal Official**: Filter ward complaints, dispatch field crews, attach resolution photo proof.
   - **City Administrator**: System statistics, manage departments & wards, export municipal CSV audit sheets.
5. **Full Audit Trail**: Every status transition records timestamp, actor, role, and official remarks.
6. **In-App Real-time Notifications**: Alert users on status updates, crew assignments, and new submissions.
7. **Exportable CSV Reports**: One-click generation of standard municipal audit sheets.

## 🛠 Tech Stack
- Frontend: React 19 + TypeScript + Vite
- Styling: Tailwind CSS v4 with custom cyan/navy civic palette
- Maps: Leaflet & OpenStreetMap (Free, Attribution Compliant)
- State & Persistence: LocalStorage engine with JSON backup/restore & clean database models
- Icons & UI: Lucide React + Framer Motion transitions

## 📦 How to Run Locally on Your Computer (100% Free)

### Prerequisites:
- Node.js (v18 or higher)
- npm (comes with Node.js)

### Step 1: Install Dependencies
\`\`\`bash
npm install
\`\`\`

### Step 2: Start Development Server
\`\`\`bash
npm run dev
\`\`\`
The application will launch immediately at \`http://localhost:3000\`.

### Step 3: Test Accounts (No Sign Up Needed)
- **Citizen Demo**: \`citizen@civicbridge.org\`
- **Official Demo**: \`official@civicbridge.org\` (Roads Inspector, Ward 101)
- **Admin Demo**: \`admin@civicbridge.org\` (City Corporation Director)
(Or switch roles instantly using the top banner Quick Switcher!)

---
*Created for College Academic Capstone Project. Source Code Released under Apache 2.0.*
`;

    zip.file('README.md', readmeContent);
    zip.file('civicbridge-data-backup.json', JSON.stringify({
      complaints: this.getComplaints(),
      users: this.getUsers(),
      departments: this.getDepartments(),
      wards: this.getWards(),
      categories: this.getCategories()
    }, null, 2));

    const content = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(content);
    const a = document.createElement('a');
    a.href = url;
    a.download = `CivicBridge_Project_Source_Code_${new Date().toISOString().split('T')[0]}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}

export const storage = StorageService.getInstance();
