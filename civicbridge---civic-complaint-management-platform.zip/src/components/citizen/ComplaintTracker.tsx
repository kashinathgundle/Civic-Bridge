import React, { useState, useMemo } from 'react';
import { Category, Complaint, ComplaintStatus, Priority, User } from '../../types';
import { LeafletMap } from '../common/LeafletMap';
import {
  Search,
  Filter,
  MapPin,
  Calendar,
  Clock,
  ArrowRight,
  Eye,
  Layers,
  Map as MapIcon,
  Grid,
  List,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';

interface ComplaintTrackerProps {
  complaints: Complaint[];
  categories: Category[];
  currentUser: User;
  onSelectComplaint: (complaint: Complaint) => void;
  initialSearchQuery?: string;
  onNewComplaintClick: () => void;
}

export const ComplaintTracker: React.FC<ComplaintTrackerProps> = ({
  complaints,
  categories,
  currentUser,
  onSelectComplaint,
  initialSearchQuery = '',
  onNewComplaintClick
}) => {
  const [search, setSearch] = useState(initialSearchQuery);
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'table' | 'map'>('grid');

  const filteredComplaints = useMemo(() => {
    return complaints.filter((c) => {
      // Search text
      if (search.trim()) {
        const query = search.trim().toLowerCase();
        const matchesId = c.id.toLowerCase().includes(query);
        const matchesTitle = c.title.toLowerCase().includes(query);
        const matchesDesc = c.description.toLowerCase().includes(query);
        const matchesAddr = c.address.toLowerCase().includes(query);
        const matchesCitizen = c.citizenName.toLowerCase().includes(query);
        if (!matchesId && !matchesTitle && !matchesDesc && !matchesAddr && !matchesCitizen) {
          return false;
        }
      }

      // Status filter
      if (selectedStatus !== 'all' && c.status !== selectedStatus) {
        return false;
      }

      // Priority filter
      if (selectedPriority !== 'all' && c.priority !== selectedPriority) {
        return false;
      }

      // Category filter
      if (selectedCategory !== 'all' && c.categoryId !== selectedCategory) {
        return false;
      }

      return true;
    });
  }, [complaints, search, selectedStatus, selectedPriority, selectedCategory]);

  const statusColors: Record<ComplaintStatus, { bg: string; text: string; border: string }> = {
    submitted: { bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-200' },
    under_review: { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200' },
    assigned: { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200' },
    in_progress: { bg: 'bg-sky-50', text: 'text-sky-700', border: 'border-sky-200' },
    resolved: { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200' },
    rejected: { bg: 'bg-slate-100', text: 'text-slate-600', border: 'border-slate-300' }
  };

  const priorityBadges: Record<Priority, { label: string; class: string }> = {
    critical: { label: 'Critical', class: 'bg-rose-100 text-rose-800 border-rose-300' },
    high: { label: 'High', class: 'bg-amber-100 text-amber-800 border-amber-300' },
    medium: { label: 'Medium', class: 'bg-sky-100 text-sky-800 border-sky-300' },
    low: { label: 'Low', class: 'bg-slate-100 text-slate-700 border-slate-200' }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header & Quick Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-sky-700 text-xs font-bold uppercase tracking-wider mb-1">
            <ShieldCheck className="w-4 h-4" />
            Public Grievance Registry
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Track Complaints & Audit Log
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Real-time municipal tracking with transparent audit timestamps and resolution certification.
          </p>
        </div>

        <button
          type="button"
          onClick={onNewComplaintClick}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-blue-700 text-white font-extrabold text-xs shadow-md shadow-sky-600/20 hover:from-sky-700 hover:to-blue-800 transition w-fit"
        >
          <Sparkles className="w-4 h-4" />
          Report New Issue
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
            <input
              type="text"
              placeholder="Search by ID (e.g. CB-2026-1042), keyword, street address, or citizen name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition"
            />
          </div>

          {/* Category Dropdown */}
          <div className="w-full md:w-56">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl font-medium"
            >
              <option value="all">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Priority Dropdown */}
          <div className="w-full md:w-44">
            <select
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value)}
              className="w-full px-3 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl font-medium"
            >
              <option value="all">All Priorities</option>
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl self-end md:self-auto">
            <button
              type="button"
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg text-xs font-bold transition ${viewMode === 'grid' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-900'}`}
              title="Card Grid View"
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg text-xs font-bold transition ${viewMode === 'table' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-900'}`}
              title="Table View"
            >
              <List className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('map')}
              className={`p-1.5 rounded-lg text-xs font-bold transition ${viewMode === 'map' ? 'bg-white text-sky-700 shadow-2xs' : 'text-slate-500 hover:text-slate-900'}`}
              title="Geographic Map View"
            >
              <MapIcon className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Status Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-2 border-t border-slate-100 text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider shrink-0 mr-1">
            Status:
          </span>
          {[
            { id: 'all', label: `All (${complaints.length})` },
            { id: 'submitted', label: `Submitted (${complaints.filter(c => c.status === 'submitted').length})` },
            { id: 'under_review', label: `Under Review (${complaints.filter(c => c.status === 'under_review').length})` },
            { id: 'assigned', label: `Assigned (${complaints.filter(c => c.status === 'assigned').length})` },
            { id: 'in_progress', label: `In Progress (${complaints.filter(c => c.status === 'in_progress').length})` },
            { id: 'resolved', label: `Resolved (${complaints.filter(c => c.status === 'resolved').length})` }
          ].map((chip) => (
            <button
              key={chip.id}
              type="button"
              onClick={() => setSelectedStatus(chip.id)}
              className={`px-3 py-1 rounded-full text-xs font-bold transition shrink-0 ${selectedStatus === chip.id ? 'bg-sky-600 text-white shadow-2xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
              {chip.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content: Map or Grid or Table */}
      {viewMode === 'map' && (
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-sky-600" />
              Interactive Municipal GIS Heatmap ({filteredComplaints.length} locations)
            </h3>
            <span className="text-xs text-slate-400">Click any marker pin to inspect details</span>
          </div>
          <LeafletMap
            mode="view_multiple"
            complaints={filteredComplaints}
            onSelectComplaint={onSelectComplaint}
            className="h-[460px] w-full rounded-xl overflow-hidden border border-slate-200"
          />
        </div>
      )}

      {viewMode === 'grid' && (
        <>
          {filteredComplaints.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 shadow-sm space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <Search className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-800">No matching grievances found</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                No complaint matches your current filter criteria. Try clearing search or status filters.
              </p>
              <button
                type="button"
                onClick={() => { setSearch(''); setSelectedStatus('all'); setSelectedPriority('all'); setSelectedCategory('all'); }}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredComplaints.map((item) => {
                const badge = statusColors[item.status];
                const priorityBadge = priorityBadges[item.priority];

                return (
                  <div
                    key={item.id}
                    onClick={() => onSelectComplaint(item)}
                    className="bg-white rounded-2xl border border-slate-200 hover:border-sky-300 shadow-2xs hover:shadow-md transition-all duration-200 overflow-hidden flex flex-col cursor-pointer group"
                  >
                    {/* Thumbnail / Header */}
                    <div className="relative h-40 bg-slate-100 overflow-hidden">
                      <img
                        src={item.photos[0] || 'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=800&auto=format&fit=crop&q=80'}
                        alt={item.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent"></div>

                      {/* Top Badges */}
                      <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-1">
                        <span className="font-mono text-xs font-black bg-slate-900/90 text-cyan-300 px-2 py-0.5 rounded-md backdrop-blur-xs border border-sky-800/60 shadow-xs">
                          {item.id}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase shadow-xs ${priorityBadge.class}`}>
                            {item.priority}
                          </span>
                          <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border uppercase shadow-xs ${badge.bg} ${badge.text} ${badge.border}`}>
                            {item.status.replace('_', ' ')}
                          </span>
                        </div>
                      </div>

                      {/* Bottom Image Overlay Details */}
                      <div className="absolute bottom-2 left-3 right-3 text-white text-xs">
                        <span className="text-[11px] font-semibold text-cyan-200 block truncate">
                          {item.categoryName}
                        </span>
                      </div>
                    </div>

                    {/* Card Body */}
                    <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                      <div>
                        <h3 className="font-extrabold text-slate-900 text-sm line-clamp-2 leading-snug group-hover:text-sky-700 transition">
                          {item.title}
                        </h3>
                        <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                          {item.description}
                        </p>
                      </div>

                      {/* Meta Footer */}
                      <div className="space-y-2 pt-2 border-t border-slate-100 text-xs text-slate-500">
                        <div className="flex items-center gap-1.5 truncate">
                          <MapPin className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                          <span className="truncate">{item.address}</span>
                        </div>

                        <div className="flex items-center justify-between text-[11px] pt-1">
                          <span className="flex items-center gap-1 text-slate-400">
                            <Clock className="w-3 h-3" />
                            {new Date(item.createdAt).toLocaleDateString()}
                          </span>

                          <span className="font-bold text-sky-600 group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                            Track Audit &rarr;
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {viewMode === 'table' && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase text-[10px] tracking-wider">
                  <th className="py-3 px-4">Complaint ID</th>
                  <th className="py-3 px-4">Title & Issue</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Ward</th>
                  <th className="py-3 px-4">Priority</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredComplaints.map((c) => {
                  const badge = statusColors[c.status];
                  const pBadge = priorityBadges[c.priority];

                  return (
                    <tr
                      key={c.id}
                      onClick={() => onSelectComplaint(c)}
                      className="hover:bg-sky-50/60 cursor-pointer transition"
                    >
                      <td className="py-3 px-4 font-mono font-bold text-sky-800">
                        {c.id}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900 max-w-xs truncate">{c.title}</div>
                        <div className="text-[11px] text-slate-500 max-w-xs truncate">{c.address}</div>
                      </td>
                      <td className="py-3 px-4 text-slate-700 font-medium">
                        {c.categoryName}
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        {c.wardName.split(' - ')[0]}
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border uppercase ${pBadge.class}`}>
                          {c.priority}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold border uppercase ${badge.bg} ${badge.text} ${badge.border}`}>
                          {c.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-500 text-[11px] whitespace-nowrap">
                        {new Date(c.createdAt).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          className="px-2.5 py-1 text-sky-700 hover:bg-sky-100 rounded-lg font-bold text-xs"
                        >
                          View &rarr;
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
