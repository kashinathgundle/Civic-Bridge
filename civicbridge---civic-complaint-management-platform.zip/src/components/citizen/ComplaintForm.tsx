import React, { useState, useEffect } from 'react';
import { Category, Complaint, Priority, User, Ward } from '../../types';
import { classifyCivicComplaint } from '../../utils/aiClassifier';
import { LeafletMap } from '../common/LeafletMap';
import { SAMPLE_COMPLAINT_PHOTOS } from '../../data/seedData';
import { storage } from '../../services/storageService';
import {
  Sparkles,
  Camera,
  MapPin,
  AlertTriangle,
  CheckCircle,
  FileText,
  Upload,
  Layers,
  ArrowRight,
  Shield,
  Info
} from 'lucide-react';

interface ComplaintFormProps {
  currentUser: User;
  categories: Category[];
  wards: Ward[];
  onComplaintSubmitted: (complaint: Complaint) => void;
  onCancel?: () => void;
}

export const ComplaintForm: React.FC<ComplaintFormProps> = ({
  currentUser,
  categories,
  wards,
  onComplaintSubmitted,
  onCancel
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [categoryId, setCategoryId] = useState(categories[0]?.id || 'cat_potholes');
  const [wardId, setWardId] = useState(currentUser.wardId || wards[0]?.id || 'ward_101');
  const [priority, setPriority] = useState<Priority>('medium');
  const [address, setAddress] = useState('Central Civic Zone, 4th Cross Road');
  const [coords, setCoords] = useState<{ lat: number; lng: number }>({
    lat: 12.9716,
    lng: 77.5946
  });
  const [photos, setPhotos] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Live Local Autonomous AI Suggestion
  const [aiSuggestion, setAiSuggestion] = useState(classifyCivicComplaint('', ''));

  useEffect(() => {
    if (title.length > 3 || description.length > 5) {
      const suggestion = classifyCivicComplaint(title, description);
      setAiSuggestion(suggestion);
    }
  }, [title, description]);

  const handleApplyAiSuggestion = () => {
    if (aiSuggestion) {
      setCategoryId(aiSuggestion.categoryId);
      setPriority(aiSuggestion.suggestedPriority);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setPhotos(prev => [...prev, reader.result as string]);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSelectSamplePhoto = (url: string, cat?: string) => {
    if (!photos.includes(url)) {
      setPhotos(prev => [...prev, url]);
    }
    if (cat && !title) {
      if (cat === 'cat_potholes') {
        setTitle('Hazardous deep pothole on main road');
        setDescription('Deep asphalt crater damaging vehicles and causing traffic slowdown during peak hours.');
      } else if (cat === 'cat_garbage') {
        setTitle('Severe uncollected garbage overflow near market');
        setDescription('Overflowing commercial dumpster spreading foul odor and attracting stray animals on the sidewalk.');
      } else if (cat === 'cat_water') {
        setTitle('Major drinking water pipe burst flooding street');
        setDescription('High pressure water pipeline rupture wasting clean potable water and flooding basements.');
      } else if (cat === 'cat_streetlights') {
        setTitle('Streetlight fixture blackout at dangerous intersection');
        setDescription('Pole light fused, creating dangerous pitch black conditions for pedestrians and evening commuters.');
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    if (title.trim().length < 5) {
      setValidationError('Please enter a clear title (at least 5 characters).');
      return;
    }
    if (description.trim().length < 10) {
      setValidationError('Please provide more description details (at least 10 characters).');
      return;
    }
    if (!address.trim()) {
      setValidationError('Please provide an incident address or landmark.');
      return;
    }

    setSubmitting(true);

    const selectedCategory = categories.find(c => c.id === categoryId) || categories[0];
    const selectedWard = wards.find(w => w.id === wardId) || wards[0];

    // Fallback photo if none uploaded to keep UI rich
    const finalPhotos = photos.length > 0 ? photos : [
      'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=800&auto=format&fit=crop&q=80'
    ];

    try {
      const created = storage.createComplaint({
        title: title.trim(),
        description: description.trim(),
        categoryId: selectedCategory.id,
        categoryName: selectedCategory.name,
        departmentId: selectedCategory.departmentId,
        departmentName: selectedCategory.departmentName,
        wardId: selectedWard.id,
        wardName: selectedWard.name,
        priority,
        citizenId: currentUser.id,
        citizenName: currentUser.name,
        citizenEmail: currentUser.email,
        citizenPhone: currentUser.phone || '+1 (555) 789-0123',
        address: address.trim(),
        coordinates: coords,
        photos: finalPhotos,
        aiSuggestion: {
          ...aiSuggestion,
          categoryId: selectedCategory.id,
          categoryName: selectedCategory.name
        }
      });

      setSubmitting(false);
      onComplaintSubmitted(created);
    } catch (err: any) {
      setSubmitting(false);
      setValidationError(err.message || 'Failed to file complaint.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 text-sky-700 text-xs font-bold uppercase tracking-wider mb-1">
          <Shield className="w-4 h-4" />
          Citizen Grievance Redressal
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Report a Public Civic Issue
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Submit details, attach photographs, and drop a location pin. Our autonomous local AI classifier will route it directly to the designated ward authority.
        </p>
      </div>

      {validationError && (
        <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm flex items-start gap-2.5">
          <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold block">Submission Incomplete</span>
            <span>{validationError}</span>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Section 1: Issue Details & AI Assist */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <FileText className="w-4 h-4 text-sky-600" />
            1. Issue Title & Description
          </h2>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Complaint Title <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g., Deep asphalt pothole causing accidents near Metro Station"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Detailed Description <span className="text-rose-500">*</span>
            </label>
            <textarea
              required
              rows={4}
              placeholder="Describe the severity, duration, hazard level, and exact surroundings..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition"
            />
          </div>

          {/* Autonomous Free AI Classifier Recommendation Card */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-sky-50 via-cyan-50 to-blue-50 border border-sky-200 text-xs">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-sky-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Sparkles className="w-4 h-4 text-cyan-200 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-slate-900 text-sm">
                      AI Category Suggestion: {aiSuggestion.categoryName}
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-sky-200 text-sky-900 font-bold text-[10px]">
                      {Math.round(aiSuggestion.confidence * 100)}% Confidence
                    </span>
                    <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] uppercase ${
                      aiSuggestion.suggestedPriority === 'critical' ? 'bg-rose-100 text-rose-800' :
                      aiSuggestion.suggestedPriority === 'high' ? 'bg-amber-100 text-amber-800' :
                      'bg-emerald-100 text-emerald-800'
                    }`}>
                      Urgency: {aiSuggestion.suggestedPriority}
                    </span>
                  </div>

                  <p className="text-slate-600 mt-1 leading-relaxed text-xs">
                    {aiSuggestion.reasoning}
                  </p>

                  {aiSuggestion.matchedKeywords.length > 0 && (
                    <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                      <span className="text-[11px] font-semibold text-slate-500">Detected Signals:</span>
                      {aiSuggestion.matchedKeywords.map((kw, i) => (
                        <span key={i} className="px-2 py-0.5 bg-white border border-sky-200 text-sky-800 rounded text-[10px] font-medium">
                          #{kw}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <button
                type="button"
                onClick={handleApplyAiSuggestion}
                className="shrink-0 px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg font-bold text-xs shadow-xs transition"
              >
                Apply AI Match
              </button>
            </div>
            <div className="mt-2.5 pt-2 border-t border-sky-200/60 text-[10px] text-slate-500 flex items-center gap-1">
              <Info className="w-3 h-3 text-sky-600" />
              100% Free Autonomous Rule-Based Classifier. No external subscription or paid AI API required.
            </div>
          </div>

          {/* Category & Priority Selectors */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Category (Manual Override Allowed)
              </label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 font-medium"
              >
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name} ({cat.departmentName})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Priority Level
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as Priority)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 font-medium"
              >
                <option value="low">Low - Routine Upkeep</option>
                <option value="medium">Medium - Standard Public Inconvenience</option>
                <option value="high">High - Active Obstruction or Spillage</option>
                <option value="critical">Critical - Urgent Life or Accident Danger</option>
              </select>
            </div>
          </div>
        </div>

        {/* Section 2: Photo Verification */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Camera className="w-4 h-4 text-sky-600" />
              2. Visual Evidence & Photo Proof
            </h2>
            <span className="text-xs text-slate-400">Upload your own photo or pick a sample</span>
          </div>

          {/* Quick Sample Selector for Instant Demo */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <span className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">
              Quick Test Photos (Click to attach instantly):
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {SAMPLE_COMPLAINT_PHOTOS.map((sample, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSelectSamplePhoto(sample.url, sample.category)}
                  className={`group relative rounded-lg overflow-hidden border text-left transition ${photos.includes(sample.url) ? 'ring-2 ring-sky-600 border-sky-600' : 'border-slate-200 hover:border-sky-400'}`}
                >
                  <img src={sample.url} alt={sample.label} className="w-full h-16 object-cover group-hover:scale-105 transition" />
                  <div className="p-1 bg-white text-[10px] font-semibold text-slate-700 truncate">
                    {sample.label}
                  </div>
                  {photos.includes(sample.url) && (
                    <div className="absolute top-1 right-1 bg-sky-600 text-white rounded-full p-0.5">
                      <CheckCircle className="w-3 h-3" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Upload Button */}
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer transition shadow-2xs">
              <Upload className="w-4 h-4 text-sky-600" />
              Upload Photo from Device
              <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
            </label>
            {photos.length > 0 && (
              <span className="text-xs font-medium text-emerald-600 flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" />
                {photos.length} photo(s) attached
              </span>
            )}
          </div>

          {/* Photo Preview Strip */}
          {photos.length > 0 && (
            <div className="flex items-center gap-3 overflow-x-auto py-2">
              {photos.map((p, idx) => (
                <div key={idx} className="relative w-24 h-20 rounded-xl overflow-hidden border border-slate-200 shrink-0 shadow-xs">
                  <img src={p} alt="Attached Evidence" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setPhotos(photos.filter((_, i) => i !== idx))}
                    className="absolute top-1 right-1 w-5 h-5 bg-slate-900/80 hover:bg-rose-600 text-white rounded-full flex items-center justify-center text-xs"
                  >
                    &times;
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Section 3: Geographic Location & Free Leaflet Map */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-sky-600" />
              3. Location & Geographic Pin (OpenStreetMap)
            </h2>
            <span className="text-xs text-slate-400">Click on the map or drag pin</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Address / Street Landmark <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Opposite Metro Pillar 142, 4th Main Road"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Designated Municipal Ward
              </label>
              <select
                value={wardId}
                onChange={(e) => setWardId(e.target.value)}
                className="w-full px-3 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 font-medium"
              >
                {wards.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.name} ({w.zone})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Leaflet Picker Map */}
          <div>
            <LeafletMap
              mode="picker"
              selectedLocation={coords}
              onLocationSelect={(newCoords) => {
                setCoords({ lat: newCoords.lat, lng: newCoords.lng });
                if (newCoords.suggestedAddress) {
                  setAddress(newCoords.suggestedAddress);
                }
              }}
              className="h-[320px] w-full rounded-xl overflow-hidden border border-slate-200"
            />
            <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2 px-1">
              <span>Selected Coordinates: <strong>{coords.lat.toFixed(5)}, {coords.lng.toFixed(5)}</strong></span>
              <span className="text-slate-400">Powered by OpenStreetMap (Free, Attribution Compliant)</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-4">
          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-xs transition"
            >
              Cancel
            </button>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="flex items-center gap-2 px-7 py-3 rounded-xl bg-gradient-to-r from-sky-600 via-blue-600 to-cyan-600 text-white font-extrabold text-sm shadow-lg shadow-sky-600/25 hover:from-sky-700 hover:to-blue-700 transition"
          >
            {submitting ? 'Generating Complaint ID...' : 'Submit Grievance & Route'}
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
};
