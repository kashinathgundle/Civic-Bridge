import React, { useState } from 'react';
import { Category, Complaint, DashboardStats, User } from '../../types';
import {
  ShieldCheck,
  Sparkles,
  Search,
  ArrowRight,
  CheckCircle2,
  Clock,
  MapPin,
  Camera,
  AlertTriangle,
  Layers,
  Wrench,
  ThumbsUp,
  FileSpreadsheet
} from 'lucide-react';

interface HomeOverviewProps {
  currentUser: User;
  stats: DashboardStats;
  categories: Category[];
  recentComplaints: Complaint[];
  onNavigateSubmit: () => void;
  onNavigateTrack: (searchQuery?: string) => void;
  onSelectComplaint: (complaint: Complaint) => void;
  onExportCsv: () => void;
}

export const HomeOverview: React.FC<HomeOverviewProps> = ({
  currentUser,
  stats,
  categories,
  recentComplaints,
  onNavigateSubmit,
  onNavigateTrack,
  onSelectComplaint,
  onExportCsv
}) => {
  const [quickTrackId, setQuickTrackId] = useState('');

  const handleQuickTrack = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickTrackId.trim()) return;
    onNavigateTrack(quickTrackId.trim());
  };

  const resolvedShowcases = recentComplaints.filter(c => c.status === 'resolved');

  return (
    <div className="space-y-12 pb-12">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-sky-950 to-slate-900 text-white py-16 sm:py-20 px-4 sm:px-6 lg:px-8 border-b border-sky-900">
        <div className="max-w-5xl mx-auto text-center space-y-6 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-400/30 text-cyan-300 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            AI-Assisted Municipal Governance Platform
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight">
            Bridging Citizens & Municipal Authorities for Faster Redressal
          </h1>

          <p className="text-sm sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Report potholes, garbage dumps, pipeline leaks, and broken streetlights in seconds. Autonomous AI classification, geo-tagging, and complete audit timeline transparency.
          </p>

          {/* Quick Tracking Search Bar */}
          <div className="max-w-xl mx-auto pt-2">
            <form onSubmit={handleQuickTrack} className="flex items-center bg-white rounded-2xl p-1.5 shadow-2xl border border-slate-200">
              <Search className="w-5 h-5 text-slate-400 ml-3 shrink-0" />
              <input
                type="text"
                placeholder="Enter Complaint ID (e.g. CB-2026-1042)..."
                value={quickTrackId}
                onChange={(e) => setQuickTrackId(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-hidden"
              />
              <button
                type="submit"
                className="px-5 py-2.5 bg-gradient-to-r from-sky-600 to-blue-700 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md hover:from-sky-700 hover:to-blue-800 transition shrink-0"
              >
                Track Now
              </button>
            </form>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <button
              type="button"
              onClick={onNavigateSubmit}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-600 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-cyan-500/20 hover:from-cyan-400 hover:to-sky-500 transition"
            >
              <Sparkles className="w-4 h-4 text-slate-950" />
              Report an Issue Now
            </button>
            <button
              type="button"
              onClick={() => onNavigateTrack()}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs sm:text-sm border border-white/20 transition"
            >
              Browse Public Grievances
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Ambient Glows */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-sky-500/10 blur-[120px] rounded-full pointer-events-none"></div>
      </section>

      {/* Live City Stats Bar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 relative z-20">
        <div className="bg-white rounded-2xl shadow-xl border border-slate-200 p-6 grid grid-cols-2 md:grid-cols-4 gap-6 divide-y md:divide-y-0 md:divide-x divide-slate-100">
          <div className="text-center pt-3 md:pt-0">
            <span className="text-3xl sm:text-4xl font-black text-slate-900 block">{stats.total}</span>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-1 block">Total Grievances Logged</span>
          </div>
          <div className="text-center pt-3 md:pt-0">
            <span className="text-3xl sm:text-4xl font-black text-emerald-600 block">{stats.resolutionRatePercent}%</span>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-1 block">Resolution Rate</span>
          </div>
          <div className="text-center pt-3 md:pt-0">
            <span className="text-3xl sm:text-4xl font-black text-sky-600 block">{stats.inProgress + stats.assigned}</span>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-1 block">Active Field Repairs</span>
          </div>
          <div className="text-center pt-3 md:pt-0">
            <span className="text-3xl sm:text-4xl font-black text-amber-600 block">{stats.avgResolutionHours}h</span>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-1 block">Average Turnaround</span>
          </div>
        </div>
      </section>

      {/* 4-Step Visual Redressal Workflow */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-xs font-extrabold text-sky-700 uppercase tracking-widest mb-1">
            End-To-End Municipal Workflow
          </h2>
          <h3 className="text-2xl sm:text-3xl font-black text-slate-900">
            How CivicBridge Delivers Accountability
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              step: '01',
              title: 'Citizen Reports',
              desc: 'Submit photos, address, and interactive GPS coordinates on OpenStreetMap with instant verification.',
              icon: Camera,
              color: 'text-sky-600 bg-sky-50'
            },
            {
              step: '02',
              title: 'Autonomous Local AI',
              desc: 'Rule-based NLP categorizes issue, extracts key hazard tokens, and flags emergency priority levels.',
              icon: Sparkles,
              color: 'text-cyan-600 bg-cyan-50'
            },
            {
              step: '03',
              title: 'Official Review & Crew',
              desc: 'Ward inspector assesses severity, schedules maintenance squad, and mobilizes field machinery.',
              icon: Wrench,
              color: 'text-amber-600 bg-amber-50'
            },
            {
              step: '04',
              title: 'Proof & Certification',
              desc: 'Official uploads resolution proof photo. Citizen verifies and grades repair satisfaction.',
              icon: CheckCircle2,
              color: 'text-emerald-600 bg-emerald-50'
            }
          ].map((item, idx) => (
            <div key={idx} className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm relative space-y-3">
              <span className="text-2xl font-black text-slate-200 block">{item.step}</span>
              <div className={`w-10 h-10 rounded-xl ${item.color} flex items-center justify-center font-bold`}>
                <item.icon className="w-5 h-5" />
              </div>
              <h4 className="font-extrabold text-slate-900 text-base">{item.title}</h4>
              <p className="text-xs text-slate-500 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Supported Civic Categories Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h3 className="text-xs font-extrabold text-sky-700 uppercase tracking-widest mb-1">
              Municipal Services Coverage
            </h3>
            <h4 className="text-2xl font-black text-slate-900">Civic Grievance Categories</h4>
          </div>
          <button
            type="button"
            onClick={onNavigateSubmit}
            className="text-xs font-bold text-sky-700 hover:text-sky-800 flex items-center gap-1"
          >
            File a grievance in these categories &rarr;
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {categories.map((cat) => (
            <div
              key={cat.id}
              onClick={onNavigateSubmit}
              className="p-4 bg-white rounded-2xl border border-slate-200 hover:border-sky-400 hover:shadow-md transition cursor-pointer space-y-2 group"
            >
              <div className="w-8 h-8 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Layers className="w-4 h-4" />
              </div>
              <h5 className="font-bold text-slate-900 text-xs sm:text-sm group-hover:text-sky-700 transition">
                {cat.name}
              </h5>
              <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                {cat.description}
              </p>
              <div className="text-[10px] text-slate-400 pt-1 font-semibold flex items-center justify-between">
                <span>{cat.departmentName.split(' & ')[0]}</span>
                <span className="text-amber-700">SLA: {cat.slaHours}h</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Before & After Resolution Showcase */}
      {resolvedShowcases.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-emerald-50 via-teal-50 to-sky-50 border border-emerald-200 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[11px] font-extrabold uppercase text-emerald-800 tracking-wider flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Verified Municipal Completion
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
                  Recent Certified Resolutions (Before & After)
                </h3>
              </div>
              <button
                type="button"
                onClick={() => onNavigateTrack()}
                className="text-xs font-bold text-emerald-800 hover:underline"
              >
                View all resolved records &rarr;
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {resolvedShowcases.slice(0, 2).map((item) => (
                <div
                  key={item.id}
                  onClick={() => onSelectComplaint(item)}
                  className="bg-white rounded-2xl p-5 border border-emerald-200/80 shadow-xs hover:shadow-md transition cursor-pointer space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-black text-sky-900 bg-sky-100 px-2 py-0.5 rounded">
                      {item.id}
                    </span>
                    <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 uppercase">
                      Resolved with Proof
                    </span>
                  </div>

                  <h4 className="font-extrabold text-slate-900 text-sm line-clamp-1">
                    {item.title}
                  </h4>

                  <div className="grid grid-cols-2 gap-2 text-center text-[10px] font-bold">
                    <div>
                      <span className="block text-slate-400 mb-1">BEFORE (Citizen Report)</span>
                      <div className="h-28 rounded-lg overflow-hidden bg-slate-100 border border-slate-200">
                        <img src={item.photos[0]} alt="Before" className="w-full h-full object-cover" />
                      </div>
                    </div>
                    <div>
                      <span className="block text-emerald-700 mb-1">AFTER (Certified Fix)</span>
                      <div className="h-28 rounded-lg overflow-hidden bg-emerald-50 border border-emerald-300">
                        <img src={item.resolutionPhoto || item.photos[0]} alt="After" className="w-full h-full object-cover" />
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 italic line-clamp-2">
                    "{item.officialRemarks || 'Work inspected and verified complete by municipal ward inspector.'}"
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
