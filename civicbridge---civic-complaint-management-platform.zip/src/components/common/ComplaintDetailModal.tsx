import React, { useState } from 'react';
import { Complaint, ComplaintStatus, Role, User } from '../../types';
import { LeafletMap } from './LeafletMap';
import { storage } from '../../services/storageService';
import {
  X,
  CheckCircle2,
  Clock,
  MapPin,
  Calendar,
  User as UserIcon,
  Shield,
  Star,
  Printer,
  Share2,
  AlertCircle,
  Sparkles,
  ExternalLink,
  Camera,
  Layers,
  ArrowRight
} from 'lucide-react';

interface ComplaintDetailModalProps {
  complaint: Complaint | null;
  currentUser: User;
  onClose: () => void;
  onUpdateStatusClick?: (complaint: Complaint) => void;
  onRefreshComplaint?: (updated: Complaint) => void;
}

export const ComplaintDetailModal: React.FC<ComplaintDetailModalProps> = ({
  complaint,
  currentUser,
  onClose,
  onUpdateStatusClick,
  onRefreshComplaint
}) => {
  const [rating, setRating] = useState<number>(complaint?.citizenRating || 5);
  const [feedbackText, setFeedbackText] = useState<string>(complaint?.citizenFeedback || '');
  const [ratingSubmitted, setRatingSubmitted] = useState<boolean>(!!complaint?.citizenRating);
  const [activePhotoTab, setActivePhotoTab] = useState<'evidence' | 'resolution'>('evidence');
  const [copied, setCopied] = useState(false);

  if (!complaint) return null;

  const steps: { status: ComplaintStatus; label: string; description: string }[] = [
    { status: 'submitted', label: 'Registered', description: 'Filed by citizen' },
    { status: 'under_review', label: 'Under Review', description: 'Municipal triage' },
    { status: 'assigned', label: 'Assigned', description: 'Forwarded to crew' },
    { status: 'in_progress', label: 'In Progress', description: 'Work underway' },
    { status: 'resolved', label: 'Resolved', description: 'Inspected & closed' }
  ];

  const statusOrder: ComplaintStatus[] = ['submitted', 'under_review', 'assigned', 'in_progress', 'resolved'];
  const currentStepIndex = statusOrder.indexOf(complaint.status);

  const handleRatingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    storage.addCitizenFeedback(complaint.id, rating, feedbackText);
    setRatingSubmitted(true);
    const updated = storage.getComplaintById(complaint.id);
    if (updated && onRefreshComplaint) {
      onRefreshComplaint(updated);
    }
  };

  const handleCopyId = () => {
    navigator.clipboard?.writeText(complaint.id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  const priorityColors = {
    low: 'bg-slate-100 text-slate-800 border-slate-200',
    medium: 'bg-sky-50 text-sky-800 border-sky-200',
    high: 'bg-amber-50 text-amber-800 border-amber-200',
    critical: 'bg-rose-50 text-rose-800 border-rose-200'
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full my-auto overflow-hidden border border-slate-200 max-h-[92vh] flex flex-col">
        {/* Top Header Bar */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <span className="font-mono text-sm sm:text-base font-extrabold text-cyan-300 bg-sky-950/80 px-2.5 py-1 rounded-lg border border-sky-800">
              {complaint.id}
            </span>
            <div className="flex items-center gap-2">
              <span className={`text-[10px] sm:text-xs font-bold px-2 py-0.5 rounded-full border uppercase ${priorityColors[complaint.priority]}`}>
                {complaint.priority}
              </span>
              <span className="text-xs text-slate-400 hidden sm:inline">
                {complaint.departmentName}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopyId}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition text-xs flex items-center gap-1"
              title="Copy Complaint ID"
            >
              <Share2 className="w-4 h-4" />
              <span className="hidden sm:inline">{copied ? 'Copied!' : 'Copy ID'}</span>
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition text-xs flex items-center gap-1"
              title="Print Receipt"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">Print</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Complaint Title & Main Meta */}
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-sky-700 mb-1">
              <span>{complaint.categoryName}</span>
              <span>&bull;</span>
              <span>{complaint.wardName}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 leading-tight">
              {complaint.title}
            </h1>
            <p className="text-xs text-slate-500 mt-1 flex items-center gap-3 flex-wrap">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                Reported {new Date(complaint.createdAt).toLocaleDateString()} at {new Date(complaint.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
              <span className="flex items-center gap-1">
                <UserIcon className="w-3.5 h-3.5 text-slate-400" />
                Citizen: {complaint.citizenName}
              </span>
            </p>
          </div>

          {/* Lifecycle Progress Stepper */}
          <div className="bg-slate-50 rounded-2xl p-4 sm:p-5 border border-slate-200">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-4">
              Grievance Lifecycle Status
            </h3>

            {complaint.status === 'rejected' ? (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="block font-bold">Complaint Closed / Rejected</strong>
                  <span>Reason: {complaint.rejectionReason || 'Duplicate or out of municipal jurisdiction.'}</span>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 relative">
                {steps.map((st, idx) => {
                  const isCompleted = currentStepIndex >= idx;
                  const isCurrent = currentStepIndex === idx;

                  return (
                    <div
                      key={st.status}
                      className={`relative p-2.5 rounded-xl border transition ${
                        isCurrent
                          ? 'bg-sky-50 border-sky-400 ring-2 ring-sky-500/20'
                          : isCompleted
                          ? 'bg-white border-emerald-200'
                          : 'bg-slate-100/60 border-slate-200 text-slate-400 opacity-70'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        {isCompleted ? (
                          <CheckCircle2 className={`w-4 h-4 ${isCurrent ? 'text-sky-600' : 'text-emerald-600'}`} />
                        ) : (
                          <div className="w-4 h-4 rounded-full border border-slate-300 flex items-center justify-center text-[10px] text-slate-400 font-bold">
                            {idx + 1}
                          </div>
                        )}
                        <span className={`text-xs font-bold ${isCurrent ? 'text-sky-900' : isCompleted ? 'text-slate-800' : 'text-slate-400'}`}>
                          {st.label}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-500 line-clamp-1">{st.description}</p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Description & Official Remarks */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl border border-slate-200 bg-white">
              <span className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                Citizen Incident Narrative
              </span>
              <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
                {complaint.description}
              </p>
              <div className="mt-3 pt-3 border-t border-slate-100 flex items-center gap-1.5 text-xs text-slate-500">
                <MapPin className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                <span className="font-medium text-slate-800">{complaint.address}</span>
              </div>
            </div>

            <div className="p-4 rounded-xl border border-sky-100 bg-sky-50/50">
              <span className="block text-[11px] font-bold text-sky-900 uppercase tracking-wider mb-1 flex items-center gap-1">
                <Shield className="w-3.5 h-3.5 text-sky-600" />
                Official Inspection & Action Notes
              </span>
              <p className="text-xs text-slate-700 leading-relaxed">
                {complaint.officialRemarks || (
                  <span className="italic text-slate-400">
                    Awaiting initial site inspection by Ward {complaint.wardName.split(' - ')[0]} officer.
                  </span>
                )}
              </p>
              <div className="mt-3 pt-3 border-t border-sky-200/50 flex flex-col gap-1 text-[11px] text-slate-600">
                <div>
                  <span className="font-semibold text-slate-700">Assigned Inspector:</span>{' '}
                  {complaint.assignedOfficialName || 'Unassigned'}
                </div>
                <div>
                  <span className="font-semibold text-slate-700">Field Squad:</span>{' '}
                  {complaint.assignedTeam || 'Routine Queue'}
                </div>
              </div>
            </div>
          </div>

          {/* Visual Proof Section (Before vs After) */}
          <div className="p-4 rounded-2xl border border-slate-200 bg-white">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-sky-600" />
                Visual Inspection Evidence
              </h3>

              {complaint.resolutionPhoto && (
                <div className="flex items-center gap-1 text-xs">
                  <button
                    type="button"
                    onClick={() => setActivePhotoTab('evidence')}
                    className={`px-2.5 py-1 rounded-md font-bold transition ${activePhotoTab === 'evidence' ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-600'}`}
                  >
                    Original Report
                  </button>
                  <button
                    type="button"
                    onClick={() => setActivePhotoTab('resolution')}
                    className={`px-2.5 py-1 rounded-md font-bold transition ${activePhotoTab === 'resolution' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'}`}
                  >
                    Resolution Proof (After)
                  </button>
                </div>
              )}
            </div>

            {complaint.resolutionPhoto ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <span className="block text-[11px] font-bold text-slate-500 mb-1">
                    BEFORE (Citizen Submission)
                  </span>
                  <div className="rounded-xl overflow-hidden border border-slate-200 h-48 bg-slate-100">
                    <img
                      src={complaint.photos[0]}
                      alt="Incident Evidence"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
                <div>
                  <span className="block text-[11px] font-bold text-emerald-700 mb-1 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    AFTER (Resolution Proof Certified by Official)
                  </span>
                  <div className="rounded-xl overflow-hidden border border-emerald-300 h-48 bg-emerald-50">
                    <img
                      src={complaint.resolutionPhoto}
                      alt="Resolution Proof"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3 overflow-x-auto">
                {complaint.photos.map((url, i) => (
                  <div key={i} className="rounded-xl overflow-hidden border border-slate-200 h-48 w-full sm:w-72 bg-slate-100 shrink-0">
                    <img src={url} alt={`Evidence ${i + 1}`} className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Interactive Geographic Location Viewer */}
          <div className="p-4 rounded-2xl border border-slate-200 bg-white">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-sky-600" />
              Geographic Pin (OpenStreetMap)
            </h3>
            <LeafletMap
              mode="view_single"
              selectedLocation={complaint.coordinates}
              className="h-[220px] w-full rounded-xl overflow-hidden border border-slate-200"
            />
          </div>

          {/* Full Audit Timeline Log */}
          <div className="p-4 rounded-2xl border border-slate-200 bg-white">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-sky-600" />
              Complete Municipal Audit Trail
            </h3>

            <div className="relative pl-6 space-y-4 border-l-2 border-slate-200 ml-2">
              {complaint.timeline.map((event, idx) => (
                <div key={event.id || idx} className="relative group">
                  <div className="absolute -left-[31px] top-0 w-3.5 h-3.5 rounded-full border-2 border-white bg-sky-600 shadow-xs"></div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-xs text-slate-900">{event.title}</span>
                      <span className="text-[10px] text-slate-400">
                        {new Date(event.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-600 mt-0.5">
                      <span className="font-medium text-slate-800">{event.actorName}</span>{' '}
                      <span className="text-slate-400 capitalize">({event.actorRole})</span>
                    </div>
                    {event.remarks && (
                      <p className="text-xs text-slate-600 bg-slate-50 p-2 rounded-lg mt-1 border border-slate-100">
                        "{event.remarks}"
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Citizen Feedback Rating (When Resolved) */}
          {complaint.status === 'resolved' && (
            <div className="p-4 rounded-2xl border border-emerald-200 bg-emerald-50/60">
              <h3 className="text-xs font-bold text-emerald-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                Citizen Quality Rating & Feedback
              </h3>

              {ratingSubmitted ? (
                <div className="flex items-center gap-3">
                  <div className="flex items-center text-amber-500">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star
                        key={s}
                        className={`w-4 h-4 ${s <= (complaint.citizenRating || 5) ? 'fill-amber-500' : 'text-slate-300'}`}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-slate-700 font-medium">
                    Rated {complaint.citizenRating || 5} out of 5 stars.
                  </span>
                </div>
              ) : currentUser.role === 'citizen' ? (
                <form onSubmit={handleRatingSubmit} className="space-y-3">
                  <p className="text-xs text-slate-600">
                    Are you satisfied with the speed and quality of this municipal repair?
                  </p>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5].map((starVal) => (
                      <button
                        type="button"
                        key={starVal}
                        onClick={() => setRating(starVal)}
                        className="p-1 hover:scale-110 transition"
                      >
                        <Star
                          className={`w-6 h-6 ${starVal <= rating ? 'text-amber-500 fill-amber-500' : 'text-slate-300'}`}
                        />
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    placeholder="Optional feedback remark for the municipal team..."
                    value={feedbackText}
                    onChange={(e) => setFeedbackText(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs bg-white border border-emerald-300 rounded-lg"
                  />
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold"
                  >
                    Submit Citizen Review
                  </button>
                </form>
              ) : (
                <p className="text-xs text-slate-500 italic">
                  Awaiting citizen satisfaction review.
                </p>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div className="text-xs text-slate-500">
            Current Stage: <strong className="text-slate-800 capitalize">{complaint.status.replace('_', ' ')}</strong>
          </div>

          <div className="flex items-center gap-2">
            {(currentUser.role === 'official' || currentUser.role === 'admin') && onUpdateStatusClick && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onUpdateStatusClick(complaint);
                }}
                className="px-4 py-2 bg-gradient-to-r from-amber-600 to-amber-700 text-white font-bold text-xs rounded-xl shadow-xs hover:from-amber-700 hover:to-amber-800 transition flex items-center gap-1.5"
              >
                <Shield className="w-3.5 h-3.5" />
                Update Status / Assign Crew
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs rounded-xl transition"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
