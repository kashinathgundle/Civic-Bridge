import React from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  Terminal,
  Code2,
  FileSpreadsheet,
  Download,
  Sparkles,
  MapPin,
  ExternalLink,
  Layers,
  Server
} from 'lucide-react';

interface ProjectGuideModalProps {
  onExportCsv: () => void;
  onExportZip: () => void;
  onClose?: () => void;
}

export const ProjectGuideModal: React.FC<ProjectGuideModalProps> = ({
  onExportCsv,
  onExportZip
}) => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Hero Presentation Card */}
      <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-blue-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl border border-sky-800">
        <div className="flex items-center gap-2 text-cyan-300 text-xs font-extrabold uppercase tracking-widest mb-2">
          <ShieldCheck className="w-4 h-4" />
          Academic Engineering Capstone Project
        </div>
        <h1 className="text-2xl sm:text-4xl font-black tracking-tight leading-tight">
          CivicBridge: AI-Assisted Civic Grievance Management
        </h1>
        <p className="text-sm sm:text-base text-slate-300 mt-2 max-w-3xl leading-relaxed">
          A full-stack, autonomous civic platform designed to operate <strong>100% free of charge</strong> with zero paid API keys, zero cloud billing, and zero external subscriptions required.
        </p>

        <div className="flex flex-wrap items-center gap-3 mt-6 pt-5 border-t border-sky-800/80">
          <button
            type="button"
            onClick={onExportZip}
            className="flex items-center gap-2 px-5 py-2.5 bg-cyan-400 hover:bg-cyan-300 text-slate-950 rounded-xl font-black text-xs shadow-md transition"
          >
            <Download className="w-4 h-4" />
            Download Complete Project (.ZIP)
          </button>
          <button
            type="button"
            onClick={onExportCsv}
            className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold text-xs border border-sky-700 transition"
          >
            <FileSpreadsheet className="w-4 h-4 text-sky-400" />
            Export Complaints Audit (.CSV)
          </button>
        </div>
      </div>

      {/* Grid: Free Architecture Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-3">
          <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center font-bold">
            <Sparkles className="w-5 h-5 text-sky-600" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">1. Autonomous Local AI Engine</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Runs 100% locally in-memory using an intelligent municipal NLP classifier with keyword n-grams and urgency scoring. <strong>Zero Gemini API or paid tokens required</strong>, with instant sub-millisecond classification.
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
            <MapPin className="w-5 h-5 text-emerald-600" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">2. Free OpenStreetMap + Leaflet</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Eliminates Google Maps API key requirements and credit card verification. Uses open-source Leaflet with interactive pins, draggable coordinates, and compliant OpenStreetMap attribution.
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold">
            <Server className="w-5 h-5 text-purple-600" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">3. Persistent Storage Engine</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Includes a structured client-side storage database with JSON import/backup, automatic seed initialization, full audit logging, and an optional Express backend script for offline submission.
          </p>
        </div>
      </div>

      {/* Step by Step Local Run Guide */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-5">
        <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <Terminal className="w-5 h-5 text-sky-600" />
          How to Run This Project on Your Personal Computer (100% Free)
        </h2>

        <div className="space-y-4 text-xs">
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
            <div className="font-bold text-slate-800 text-sm">Step 1: Download or Unpack Source Code</div>
            <p className="text-slate-600">
              Click the <strong>"Download Complete Project (.ZIP)"</strong> button at the top of this page, or clone the project repository into any folder on your laptop.
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
            <div className="font-bold text-slate-800 text-sm">Step 2: Install Open-Source Dependencies</div>
            <p className="text-slate-600">
              Open your terminal (Command Prompt on Windows, Terminal on Mac/Linux) in the project directory and run:
            </p>
            <pre className="p-3 bg-slate-900 text-cyan-300 rounded-lg font-mono text-xs overflow-x-auto">
              npm install
            </pre>
            <p className="text-slate-500 text-[11px]">
              This installs standard open-source libraries (React, Vite, Leaflet, Lucide icons, JSZip).
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
            <div className="font-bold text-slate-800 text-sm">Step 3: Launch Local Web App</div>
            <pre className="p-3 bg-slate-900 text-emerald-400 rounded-lg font-mono text-xs overflow-x-auto">
              npm run dev
            </pre>
            <p className="text-slate-600">
              Open your web browser and navigate to <code className="font-mono text-sky-700 bg-sky-50 px-1 py-0.5 rounded">http://localhost:3000</code>. The app runs immediately with all demo data and maps active!
            </p>
          </div>
        </div>
      </div>

      {/* Pre-Configured Test Accounts Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="p-5 bg-slate-50 border-b border-slate-200">
          <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
            Pre-Configured Test Accounts (Evaluation Matrix)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            You can also switch between these accounts instantly using the top navigation bar switcher.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100 text-slate-600 font-bold uppercase text-[10px]">
                <th className="py-2.5 px-4">Role</th>
                <th className="py-2.5 px-4">Name</th>
                <th className="py-2.5 px-4">Email Address</th>
                <th className="py-2.5 px-4">Password</th>
                <th className="py-2.5 px-4">Assigned Scope</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              <tr>
                <td className="py-3 px-4 font-bold text-emerald-700">Citizen</td>
                <td className="py-3 px-4 font-semibold text-slate-800">Aarav Sharma</td>
                <td className="py-3 px-4 font-mono text-slate-600">citizen@civicbridge.org</td>
                <td className="py-3 px-4 font-mono text-slate-500">demo123</td>
                <td className="py-3 px-4 text-slate-600">File issues, track status, rate work</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-bold text-amber-700">Official</td>
                <td className="py-3 px-4 font-semibold text-slate-800">Inspector Vikram Patel</td>
                <td className="py-3 px-4 font-mono text-slate-600">official@civicbridge.org</td>
                <td className="py-3 px-4 font-mono text-slate-500">demo123</td>
                <td className="py-3 px-4 text-slate-600">Roads Dept &bull; Ward 101 &bull; Dispatch crews</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-bold text-purple-700">Administrator</td>
                <td className="py-3 px-4 font-semibold text-slate-800">Director Sunita Rao</td>
                <td className="py-3 px-4 font-mono text-slate-600">admin@civicbridge.org</td>
                <td className="py-3 px-4 font-mono text-slate-500">demo123</td>
                <td className="py-3 px-4 text-slate-600">Citywide analytics &bull; User roles &bull; CSV exports</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
