import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { Complaint, ComplaintStatus } from '../../types';
import { MapPin, Navigation, Compass, Layers } from 'lucide-react';

interface LeafletMapProps {
  mode: 'picker' | 'view_single' | 'view_multiple';
  center?: { lat: number; lng: number };
  zoom?: number;
  selectedLocation?: { lat: number; lng: number };
  complaints?: Complaint[];
  activeComplaintId?: string;
  onLocationSelect?: (coords: { lat: number; lng: number; suggestedAddress?: string }) => void;
  onSelectComplaint?: (complaint: Complaint) => void;
  className?: string;
}

const DEFAULT_CENTER = { lat: 12.9716, lng: 77.5946 }; // Default municipal center

// Helper to create clean, responsive SVG marker icons
function createSvgPin(color: string, label?: string, isPulse?: boolean) {
  const pulseRing = isPulse
    ? `<span class="absolute -inset-1 rounded-full animate-ping opacity-75" style="background-color: ${color}"></span>`
    : '';

  return L.divIcon({
    className: 'custom-leaflet-marker',
    html: `
      <div class="relative flex items-center justify-center cursor-pointer transition-transform hover:scale-110">
        ${pulseRing}
        <div class="w-8 h-8 rounded-full shadow-lg flex items-center justify-center border-2 border-white text-white font-bold text-xs" style="background-color: ${color}">
          ${label ? label : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>'}
        </div>
        <div class="absolute -bottom-1 w-2 h-2 rotate-45 border-r border-b border-white" style="background-color: ${color}"></div>
      </div>
    `,
    iconSize: [32, 38],
    iconAnchor: [16, 38],
    popupAnchor: [0, -36]
  });
}

const STATUS_COLOR_MAP: Record<ComplaintStatus, string> = {
  submitted: '#f43f5e',     // Rose / Alert
  under_review: '#f59e0b',  // Amber
  assigned: '#3b82f6',      // Blue
  in_progress: '#0284c7',   // Sky/Cyan
  resolved: '#10b981',      // Emerald Green
  rejected: '#64748b'       // Slate Gray
};

export const LeafletMap: React.FC<LeafletMapProps> = ({
  mode,
  center = DEFAULT_CENTER,
  zoom = 13,
  selectedLocation,
  complaints = [],
  activeComplaintId,
  onLocationSelect,
  onSelectComplaint,
  className = 'h-[360px] w-full rounded-xl overflow-hidden'
}) => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerLayerRef = useRef<L.LayerGroup | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [activeTileLayer, setActiveTileLayer] = useState<'osm' | 'topo'>('osm');

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return; // already initialized

    const initialCenter: [number, number] = selectedLocation
      ? [selectedLocation.lat, selectedLocation.lng]
      : [center.lat, center.lng];

    const map = L.map(mapContainerRef.current, {
      center: initialCenter,
      zoom: zoom,
      scrollWheelZoom: true,
      attributionControl: true
    });

    // Add Free OpenStreetMap tile layer (100% free with official OSM attribution)
    const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a> contributors | CivicBridge'
    }).addTo(map);

    const markerGroup = L.layerGroup().addTo(map);
    markerLayerRef.current = markerGroup;
    mapInstanceRef.current = map;

    // Handle map clicks in picker mode
    if (mode === 'picker') {
      map.on('click', async (e: L.LeafletMouseEvent) => {
        const { lat, lng } = e.latlng;
        setGpsError(null);

        // Try free reverse geocoding via Nominatim with fallback
        let suggestedAddr = '';
        try {
          const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`, {
            headers: {
              'Accept': 'application/json'
            }
          });
          if (res.ok) {
            const data = await res.json();
            if (data && data.display_name) {
              suggestedAddr = data.display_name;
            }
          }
        } catch {
          // Gracefully silent fallback
          suggestedAddr = `Geo Point (${lat.toFixed(4)}, ${lng.toFixed(4)})`;
        }

        if (onLocationSelect) {
          onLocationSelect({ lat, lng, suggestedAddress: suggestedAddr });
        }
      });
    }

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update Markers based on Props
  useEffect(() => {
    const map = mapInstanceRef.current;
    const layer = markerLayerRef.current;
    if (!map || !layer) return;

    layer.clearLayers();

    if (mode === 'picker') {
      if (selectedLocation) {
        const marker = L.marker([selectedLocation.lat, selectedLocation.lng], {
          icon: createSvgPin('#0284c7', '📍', true),
          draggable: true
        });

        marker.on('dragend', async (e) => {
          const target = e.target;
          const pos = target.getLatLng();
          if (onLocationSelect) {
            onLocationSelect({ lat: pos.lat, lng: pos.lng });
          }
        });

        marker.bindPopup(`
          <div class="text-xs p-1">
            <strong class="text-sky-900 block font-semibold">Selected Incident Spot</strong>
            <span class="text-slate-600">${selectedLocation.lat.toFixed(5)}, ${selectedLocation.lng.toFixed(5)}</span>
            <p class="text-slate-400 mt-0.5">Drag pin to fine-tune</p>
          </div>
        `).openPopup();

        layer.addLayer(marker);
        map.panTo([selectedLocation.lat, selectedLocation.lng]);
      }
    } else if (mode === 'view_single') {
      if (selectedLocation) {
        const marker = L.marker([selectedLocation.lat, selectedLocation.lng], {
          icon: createSvgPin('#0ea5e9')
        });
        marker.bindPopup(`
          <div class="text-xs p-1 font-sans">
            <strong class="text-slate-800 font-bold block">Incident Location</strong>
            <span class="text-slate-600">${selectedLocation.lat.toFixed(4)}, ${selectedLocation.lng.toFixed(4)}</span>
          </div>
        `).openPopup();
        layer.addLayer(marker);
        map.setView([selectedLocation.lat, selectedLocation.lng], 14);
      }
    } else if (mode === 'view_multiple') {
      if (complaints.length > 0) {
        const bounds: [number, number][] = [];

        complaints.forEach((c) => {
          if (!c.coordinates || isNaN(c.coordinates.lat) || isNaN(c.coordinates.lng)) return;

          const color = STATUS_COLOR_MAP[c.status] || '#0284c7';
          const isSelected = c.id === activeComplaintId;
          const marker = L.marker([c.coordinates.lat, c.coordinates.lng], {
            icon: createSvgPin(color, isSelected ? '★' : undefined, isSelected)
          });

          const popupContent = `
            <div class="p-2 font-sans max-w-[220px]">
              <div class="flex items-center justify-between gap-1 mb-1">
                <span class="font-mono text-xs font-bold text-sky-800">${c.id}</span>
                <span class="px-1.5 py-0.5 rounded text-[10px] font-semibold text-white uppercase" style="background-color: ${color}">
                  ${c.status.replace('_', ' ')}
                </span>
              </div>
              <h4 class="font-semibold text-slate-900 text-xs line-clamp-2 leading-tight">${c.title}</h4>
              <p class="text-[11px] text-slate-500 mt-1 line-clamp-1">${c.address}</p>
              <div class="mt-2 pt-1 border-t border-slate-100 flex items-center justify-between">
                <span class="text-[10px] font-medium text-slate-400 capitalize">${c.priority} Priority</span>
                <button id="btn-${c.id}" class="text-[11px] font-semibold text-sky-600 hover:text-sky-800">
                  Inspect &rarr;
                </button>
              </div>
            </div>
          `;

          marker.bindPopup(popupContent);

          marker.on('popupopen', () => {
            const btn = document.getElementById(`btn-${c.id}`);
            if (btn && onSelectComplaint) {
              btn.onclick = () => onSelectComplaint(c);
            }
          });

          layer.addLayer(marker);
          bounds.push([c.coordinates.lat, c.coordinates.lng]);
        });

        if (bounds.length > 1) {
          map.fitBounds(bounds, { padding: [30, 30], maxZoom: 15 });
        } else if (bounds.length === 1) {
          map.setView(bounds[0], 14);
        }
      }
    }
  }, [selectedLocation, complaints, activeComplaintId, mode]);

  // GPS Current Location Button
  const handleUseMyLocation = () => {
    if (!navigator.geolocation) {
      setGpsError('Geolocation is not supported by your browser.');
      return;
    }

    setIsLocating(true);
    setGpsError(null);

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        setIsLocating(false);
        const { latitude, longitude } = pos.coords;
        if (mapInstanceRef.current) {
          mapInstanceRef.current.setView([latitude, longitude], 15);
        }

        let address = `Coordinates: ${latitude.toFixed(5)}, ${longitude.toFixed(5)}`;
        try {
          const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18`, {
            headers: { 'Accept': 'application/json' }
          });
          if (res.ok) {
            const data = await res.json();
            if (data?.display_name) address = data.display_name;
          }
        } catch {
          // ignore
        }

        if (onLocationSelect) {
          onLocationSelect({ lat: latitude, lng: longitude, suggestedAddress: address });
        }
      },
      (err) => {
        setIsLocating(false);
        setGpsError('Unable to retrieve location (permission denied or timeout). Pick on the map instead.');
      },
      { timeout: 8000, enableHighAccuracy: true }
    );
  };

  // City Presets
  const setCityPreset = (lat: number, lng: number, name: string) => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setView([lat, lng], 14);
    }
    if (onLocationSelect && mode === 'picker') {
      onLocationSelect({ lat, lng, suggestedAddress: `${name}, Municipal Zone` });
    }
  };

  return (
    <div className="relative group">
      <div ref={mapContainerRef} className={className} />

      {/* Floating Toolbar Controls */}
      <div className="absolute top-3 right-3 z-[1000] flex flex-col gap-1.5 shadow-md">
        {mode === 'picker' && (
          <button
            type="button"
            onClick={handleUseMyLocation}
            disabled={isLocating}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/95 text-slate-800 text-xs font-semibold shadow hover:bg-sky-50 hover:text-sky-700 transition border border-slate-200"
            title="Use My Current GPS Location"
          >
            <Navigation className={`w-3.5 h-3.5 text-sky-600 ${isLocating ? 'animate-spin' : ''}`} />
            {isLocating ? 'Detecting...' : 'My Location'}
          </button>
        )}
      </div>

      {/* Quick City Presets in Picker Mode */}
      {mode === 'picker' && (
        <div className="absolute bottom-2 left-2 right-2 z-[1000] flex flex-wrap items-center gap-1.5 bg-white/90 backdrop-blur-sm p-1.5 rounded-lg border border-slate-200/80 text-[11px] shadow">
          <span className="font-semibold text-slate-600 flex items-center gap-1">
            <Compass className="w-3 h-3 text-sky-600" />
            Quick Presets:
          </span>
          <button
            type="button"
            onClick={() => setCityPreset(12.9716, 77.5946, 'Central City Plaza')}
            className="px-2 py-0.5 rounded bg-slate-100 hover:bg-sky-100 hover:text-sky-800 transition font-medium"
          >
            Central Plaza
          </button>
          <button
            type="button"
            onClick={() => setCityPreset(12.9854, 77.6050, 'University Campus')}
            className="px-2 py-0.5 rounded bg-slate-100 hover:bg-sky-100 hover:text-sky-800 transition font-medium"
          >
            University
          </button>
          <button
            type="button"
            onClick={() => setCityPreset(12.9650, 77.6180, 'Market & Metro')}
            className="px-2 py-0.5 rounded bg-slate-100 hover:bg-sky-100 hover:text-sky-800 transition font-medium"
          >
            Metro Market
          </button>
          <button
            type="button"
            onClick={() => setCityPreset(12.9520, 77.5830, 'Lakeside Residential')}
            className="px-2 py-0.5 rounded bg-slate-100 hover:bg-sky-100 hover:text-sky-800 transition font-medium"
          >
            Lakeside
          </button>
        </div>
      )}

      {/* Map Legend for Multi-Marker View */}
      {mode === 'view_multiple' && (
        <div className="absolute bottom-2 left-2 z-[1000] bg-white/95 backdrop-blur-md px-2.5 py-1.5 rounded-lg border border-slate-200 shadow text-[10px] flex items-center gap-2.5">
          <span className="font-bold text-slate-700">Legend:</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-rose-500"></span> New</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-500"></span> Review</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-sky-600"></span> In Progress</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500"></span> Resolved</span>
        </div>
      )}

      {gpsError && (
        <div className="absolute top-12 right-3 z-[1000] bg-rose-50 border border-rose-200 text-rose-700 text-xs px-2.5 py-1.5 rounded-md shadow max-w-xs">
          {gpsError}
        </div>
      )}
    </div>
  );
};
