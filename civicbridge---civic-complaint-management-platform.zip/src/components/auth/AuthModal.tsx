import React, { useState } from 'react';
import { Role, User, Ward } from '../../types';
import { storage } from '../../services/storageService';
import { DEMO_USERS } from '../../data/seedData';
import {
  X,
  UserCheck,
  Shield,
  Building,
  Mail,
  Lock,
  Phone,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: User) => void;
  wards: Ward[];
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  wards
}) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [selectedWard, setSelectedWard] = useState(wards[0]?.id || 'ward_101');
  const [selectedRole, setSelectedRole] = useState<Role>('citizen');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleQuickLogin = (demoEmail: string) => {
    setError(null);
    const user = storage.loginUser(demoEmail);
    if (user) {
      onSuccess(user);
      onClose();
    } else {
      setError('Account not found in local database.');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (mode === 'login') {
      if (!email.trim()) {
        setError('Please enter your email address.');
        return;
      }
      const user = storage.loginUser(email.trim());
      if (user) {
        onSuccess(user);
        onClose();
      } else {
        setError(`No account found for "${email}". Try registering or using one of the demo accounts below.`);
      }
    } else {
      // Register
      if (!name.trim()) {
        setError('Please enter your full name.');
        return;
      }
      if (!email.trim() || !email.includes('@')) {
        setError('Please enter a valid email address.');
        return;
      }

      try {
        const newUser = storage.registerUser(
          name.trim(),
          email.trim(),
          selectedRole,
          phone.trim() || undefined,
          selectedWard
        );
        onSuccess(newUser);
        onClose();
      } catch (err: any) {
        setError(err.message || 'Failed to register account.');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-slate-900 to-sky-950 p-6 text-white relative">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-lg bg-sky-500/20 border border-sky-400/30 flex items-center justify-center">
              <Shield className="w-4 h-4 text-cyan-300" />
            </div>
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-300">
              CivicBridge Access Portal
            </span>
          </div>
          <h2 className="text-xl font-extrabold text-white">
            {mode === 'login' ? 'Sign In to Your Account' : 'Register Citizen Account'}
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            {mode === 'login'
              ? 'Access complaints, track statuses, or switch roles for grading.'
              : 'Join the civic community to report infrastructure issues.'}
          </p>
        </div>

        {/* 1-Click Demo Accounts Bar */}
        <div className="p-4 bg-slate-50 border-b border-slate-200">
          <p className="text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2 flex items-center gap-1">
            <UserCheck className="w-3.5 h-3.5 text-sky-600" />
            Instant 1-Click Demo Accounts:
          </p>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => handleQuickLogin('citizen@civicbridge.org')}
              className="px-2 py-1.5 rounded-lg border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-left transition group"
            >
              <span className="block text-[11px] font-bold text-emerald-800">Citizen</span>
              <span className="block text-[9px] text-emerald-600 truncate">Aarav Sharma</span>
            </button>
            <button
              type="button"
              onClick={() => handleQuickLogin('official@civicbridge.org')}
              className="px-2 py-1.5 rounded-lg border border-amber-200 bg-amber-50 hover:bg-amber-100 text-left transition group"
            >
              <span className="block text-[11px] font-bold text-amber-800">Official</span>
              <span className="block text-[9px] text-amber-600 truncate">Insp. Vikram</span>
            </button>
            <button
              type="button"
              onClick={() => handleQuickLogin('admin@civicbridge.org')}
              className="px-2 py-1.5 rounded-lg border border-purple-200 bg-purple-50 hover:bg-purple-100 text-left transition group"
            >
              <span className="block text-[11px] font-bold text-purple-800">Admin</span>
              <span className="block text-[9px] text-purple-600 truncate">Dir. Sunita</span>
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-500" />
              <span>{error}</span>
            </div>
          )}

          {mode === 'register' && (
            <>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Priya Sharma"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Phone Number</label>
                <div className="relative">
                  <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="tel"
                    placeholder="+1 (555) 000-0000"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-8 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Residential Ward</label>
                <select
                  value={selectedWard}
                  onChange={(e) => setSelectedWard(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                >
                  {wards.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name} ({w.zone})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Register As</label>
                <div className="grid grid-cols-2 gap-2">
                  <label className={`p-2 rounded-lg border text-xs font-semibold cursor-pointer flex items-center justify-between ${selectedRole === 'citizen' ? 'border-sky-500 bg-sky-50 text-sky-800' : 'border-slate-200 text-slate-600'}`}>
                    <span>Citizen</span>
                    <input
                      type="radio"
                      name="role"
                      checked={selectedRole === 'citizen'}
                      onChange={() => setSelectedRole('citizen')}
                      className="sr-only"
                    />
                    {selectedRole === 'citizen' && <CheckCircle className="w-3.5 h-3.5 text-sky-600" />}
                  </label>
                  <label className={`p-2 rounded-lg border text-xs font-semibold cursor-pointer flex items-center justify-between ${selectedRole === 'official' ? 'border-amber-500 bg-amber-50 text-amber-800' : 'border-slate-200 text-slate-600'}`}>
                    <span>Official / Inspector</span>
                    <input
                      type="radio"
                      name="role"
                      checked={selectedRole === 'official'}
                      onChange={() => setSelectedRole('official')}
                      className="sr-only"
                    />
                    {selectedRole === 'official' && <CheckCircle className="w-3.5 h-3.5 text-amber-600" />}
                  </label>
                </div>
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Email Address</label>
            <div className="relative">
              <Mail className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="email"
                required
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-8 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Password</label>
            <div className="relative">
              <Lock className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="password"
                placeholder={mode === 'login' ? 'Any password works for demo' : 'Create a secure password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-8 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-sky-600 to-blue-700 text-white font-bold text-xs shadow-md shadow-sky-600/20 hover:from-sky-700 hover:to-blue-800 transition"
          >
            {mode === 'login' ? 'Sign In' : 'Create Free Account'}
          </button>

          <div className="text-center pt-2 border-t border-slate-100">
            {mode === 'login' ? (
              <p className="text-xs text-slate-500">
                Don't have an account?{' '}
                <button
                  type="button"
                  onClick={() => { setMode('register'); setError(null); }}
                  className="font-bold text-sky-600 hover:underline"
                >
                  Register here
                </button>
              </p>
            ) : (
              <p className="text-xs text-slate-500">
                Already registered?{' '}
                <button
                  type="button"
                  onClick={() => { setMode('login'); setError(null); }}
                  className="font-bold text-sky-600 hover:underline"
                >
                  Sign in instead
                </button>
              </p>
            )}
          </div>
        </form>

        <div className="px-6 py-2.5 bg-slate-50 border-t border-slate-100 text-[10px] text-slate-400 text-center">
          🔒 College Project Free Sandbox — Zero external credentials or billing required.
        </div>
      </div>
    </div>
  );
};
