import React, { useState } from 'react';
import {
  Category,
  Complaint,
  DashboardStats,
  Department,
  Role,
  User,
  Ward
} from '../../types';
import { storage } from '../../services/storageService';
import {
  BarChart3,
  Users,
  Building,
  Layers,
  Download,
  RotateCcw,
  ShieldCheck,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Plus,
  FileSpreadsheet,
  Settings,
  Sparkles,
  ExternalLink
} from 'lucide-react';

interface AdminDashboardProps {
  currentUser: User;
  stats: DashboardStats;
  complaints: Complaint[];
  users: User[];
  departments: Department[];
  wards: Ward[];
  categories: Category[];
  onRefreshData: () => void;
  onSelectComplaint: (complaint: Complaint) => void;
  onExportCsv: () => void;
  onExportZip: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  currentUser,
  stats,
  complaints,
  users,
  departments,
  wards,
  categories,
  onRefreshData,
  onSelectComplaint,
  onExportCsv,
  onExportZip
}) => {
  const [activeTab, setActiveTab] = useState<'kpi' | 'complaints' | 'users' | 'categories' | 'tools'>('kpi');
  const [userRoleChangeSuccess, setUserRoleChangeSuccess] = useState<string | null>(null);

  // New category form state
  const [newCatName, setNewCatName] = useState('');
  const [newCatDept, setNewCatDept] = useState(departments[0]?.id || 'dept_roads');
  const [newCatSla, setNewCatSla] = useState(24);
  const [catCreatedMsg, setCatCreatedMsg] = useState(false);

  const handleRoleChange = (userId: string, newRole: Role) => {
    storage.updateUserRole(userId, newRole);
    setUserRoleChangeSuccess(`User role updated to ${newRole.toUpperCase()}`);
    onRefreshData();
    setTimeout(() => setUserRoleChangeSuccess(null), 3000);
  };

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;

    const dept = departments.find(d => d.id === newCatDept) || departments[0];
    const newCat: Category = {
      id: `cat_${Date.now()}`,
      name: newCatName.trim(),
      code: newCatName.trim().toUpperCase().replace(/\s+/g, '_').substring(0, 8),
      departmentId: dept.id,
      departmentName: dept.name,
      iconName: 'AlertCircle',
      description: `Citizen grievance category for ${newCatName.trim()}`,
      defaultPriority: 'medium',
      slaHours: Number(newCatSla) || 24
    };

    storage.saveCategory(newCat);
    setNewCatName('');
    setCatCreatedMsg(true);
    onRefreshData();
    setTimeout(() => setCatCreatedMsg(false), 3000);
  };

  const handleResetData = () => {
    if (window.confirm('Reset all demo complaints and accounts back to initial seed data?')) {
      storage.resetAllToSeed();
      onRefreshData();
      alert('Pristine demo database restored successfully.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-blue-900 rounded-2xl p-6 text-white shadow-lg border border-sky-800">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-purple-500 text-white flex items-center justify-center font-extrabold text-lg shadow-md">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight">Central Municipal Control Center</h1>
                <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-400/30">
                  Super Administrator
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                City Director: <span className="text-cyan-300 font-semibold">{currentUser.name}</span> &bull; Full Jurisdiction Oversight & Analytics
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onExportCsv}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl font-bold text-xs shadow-xs transition"
            >
              <FileSpreadsheet className="w-4 h-4" />
              Export CSV
            </button>
            <button
              type="button"
              onClick={onExportZip}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded-xl font-bold text-xs border border-sky-800 transition"
            >
              <Download className="w-4 h-4" />
              Source ZIP
            </button>
          </div>
        </div>

        {/* High-level KPI Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-6 pt-5 border-t border-sky-800/80">
          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Total Grievances
            </span>
            <span className="text-2xl font-black text-white">{stats.total}</span>
            <span className="text-[10px] text-cyan-300 block mt-0.5">All wards combined</span>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Resolution Rate
            </span>
            <span className="text-2xl font-black text-emerald-400">{stats.resolutionRatePercent}%</span>
            <span className="text-[10px] text-emerald-300 block mt-0.5">{stats.resolved} complaints closed</span>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Active In-Field
            </span>
            <span className="text-2xl font-black text-sky-400">{stats.inProgress + stats.assigned}</span>
            <span className="text-[10px] text-sky-300 block mt-0.5">Assigned to squads</span>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Average SLA
            </span>
            <span className="text-2xl font-black text-amber-300">{stats.avgResolutionHours} hrs</span>
            <span className="text-[10px] text-amber-300 block mt-0.5">Turnaround time</span>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Critical Alerts
            </span>
            <span className="text-2xl font-black text-rose-400">{stats.critical}</span>
            <span className="text-[10px] text-rose-300 block mt-0.5">Immediate safety risk</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-2xl p-2 border border-slate-200 shadow-sm flex items-center gap-1.5 overflow-x-auto text-xs">
        <button
          type="button"
          onClick={() => setActiveTab('kpi')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold transition shrink-0 ${activeTab === 'kpi' ? 'bg-sky-600 text-white shadow-2xs' : 'text-slate-600 hover:bg-slate-100'}`}
        >
          <BarChart3 className="w-4 h-4" />
          Analytics & Performance
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('complaints')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold transition shrink-0 ${activeTab === 'complaints' ? 'bg-sky-600 text-white shadow-2xs' : 'text-slate-600 hover:bg-slate-100'}`}
        >
          <Layers className="w-4 h-4" />
          Complaints Master ({complaints.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('users')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold transition shrink-0 ${activeTab === 'users' ? 'bg-sky-600 text-white shadow-2xs' : 'text-slate-600 hover:bg-slate-100'}`}
        >
          <Users className="w-4 h-4" />
          User Roles ({users.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('categories')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold transition shrink-0 ${activeTab === 'categories' ? 'bg-sky-600 text-white shadow-2xs' : 'text-slate-600 hover:bg-slate-100'}`}
        >
          <Building className="w-4 h-4" />
          Departments & Categories
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('tools')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold transition shrink-0 ${activeTab === 'tools' ? 'bg-sky-600 text-white shadow-2xs' : 'text-slate-600 hover:bg-slate-100'}`}
        >
          <Settings className="w-4 h-4" />
          Database & Export Tools
        </button>
      </div>

      {userRoleChangeSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{userRoleChangeSuccess}</span>
        </div>
      )}

      {/* Tab 1: KPI Analytics */}
      {activeTab === 'kpi' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Status Breakdown Bar Card */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <BarChart3 className="w-4 h-4 text-sky-600" />
                Grievance Status Distribution
              </h3>

              <div className="space-y-3">
                {[
                  { label: 'Submitted (New)', count: stats.submitted, color: 'bg-rose-500' },
                  { label: 'Under Review', count: stats.underReview, color: 'bg-amber-500' },
                  { label: 'Assigned to Crew', count: stats.assigned, color: 'bg-blue-500' },
                  { label: 'In Progress / Maintenance', count: stats.inProgress, color: 'bg-sky-500' },
                  { label: 'Resolved (Closed)', count: stats.resolved, color: 'bg-emerald-500' }
                ].map((s) => {
                  const percent = stats.total > 0 ? Math.round((s.count / stats.total) * 100) : 0;
                  return (
                    <div key={s.label} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-700">{s.label}</span>
                        <span className="font-bold text-slate-900">{s.count} ({percent}%)</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                        <div className={`h-full rounded-full ${s.color}`} style={{ width: `${percent}%` }}></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Department Load Distribution */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Building className="w-4 h-4 text-sky-600" />
                Departmental Caseload & SLA
              </h3>

              <div className="space-y-3">
                {departments.map((dept) => {
                  const deptComplaints = complaints.filter(c => c.departmentId === dept.id);
                  const resolvedDept = deptComplaints.filter(c => c.status === 'resolved').length;
                  const rate = deptComplaints.length > 0 ? Math.round((resolvedDept / deptComplaints.length) * 100) : 100;

                  return (
                    <div key={dept.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-900">{dept.name}</span>
                        <span className="font-bold text-sky-700">{deptComplaints.length} cases ({rate}% resolved)</span>
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-slate-500">
                        <span>Lead: {dept.headName}</span>
                        <span>Code: {dept.code}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Complaints Master */}
      {activeTab === 'complaints' && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              All Municipal Grievances ({complaints.length})
            </span>
            <button
              type="button"
              onClick={onExportCsv}
              className="flex items-center gap-1 px-3 py-1.5 bg-sky-600 text-white rounded-lg text-xs font-bold"
            >
              <Download className="w-3.5 h-3.5" />
              Download CSV Audit Sheet
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100/60 text-slate-600 font-bold uppercase text-[10px]">
                  <th className="py-2.5 px-4">ID</th>
                  <th className="py-2.5 px-4">Title</th>
                  <th className="py-2.5 px-4">Department</th>
                  <th className="py-2.5 px-4">Ward</th>
                  <th className="py-2.5 px-4">Status</th>
                  <th className="py-2.5 px-4">Citizen</th>
                  <th className="py-2.5 px-4 text-right">Inspect</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {complaints.map((c) => (
                  <tr
                    key={c.id}
                    onClick={() => onSelectComplaint(c)}
                    className="hover:bg-sky-50/60 cursor-pointer"
                  >
                    <td className="py-2.5 px-4 font-mono font-bold text-sky-800">{c.id}</td>
                    <td className="py-2.5 px-4 font-semibold text-slate-900 max-w-xs truncate">{c.title}</td>
                    <td className="py-2.5 px-4 text-slate-600">{c.departmentName}</td>
                    <td className="py-2.5 px-4 text-slate-600">{c.wardName.split(' - ')[0]}</td>
                    <td className="py-2.5 px-4">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-slate-100 border text-slate-800">
                        {c.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-slate-600">{c.citizenName}</td>
                    <td className="py-2.5 px-4 text-right">
                      <button className="text-sky-600 hover:underline font-bold text-xs">
                        Audit &rarr;
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: User Management */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
          <div className="p-4 bg-slate-50 border-b border-slate-200">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              System Accounts & Role Management
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Promote citizens to Municipal Officials or Corporation Administrators dynamically.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100/60 text-slate-600 font-bold uppercase text-[10px]">
                  <th className="py-2.5 px-4">Name</th>
                  <th className="py-2.5 px-4">Email</th>
                  <th className="py-2.5 px-4">Current Role</th>
                  <th className="py-2.5 px-4">Assigned Ward</th>
                  <th className="py-2.5 px-4 text-right">Change Role</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-bold text-slate-900">{u.name}</td>
                    <td className="py-3 px-4 text-slate-600">{u.email}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] uppercase border ${
                        u.role === 'admin' ? 'bg-purple-50 text-purple-800 border-purple-200' :
                        u.role === 'official' ? 'bg-amber-50 text-amber-800 border-amber-200' :
                        'bg-emerald-50 text-emerald-800 border-emerald-200'
                      }`}>
                        {u.role}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {u.wardId ? u.wardId.replace('_', ' ').toUpperCase() : 'Central Office'}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <select
                        value={u.role}
                        onChange={(e) => handleRoleChange(u.id, e.target.value as Role)}
                        className="px-2 py-1 bg-white border border-slate-300 rounded-lg text-xs font-semibold"
                      >
                        <option value="citizen">Citizen</option>
                        <option value="official">Official</option>
                        <option value="admin">Administrator</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 4: Categories & Departments */}
      {activeTab === 'categories' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Add Category Form */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Plus className="w-4 h-4 text-sky-600" />
              Add Grievance Category
            </h3>

            {catCreatedMsg && (
              <div className="p-2.5 bg-emerald-50 text-emerald-800 text-xs rounded-lg font-medium">
                New category added successfully!
              </div>
            )}

            <form onSubmit={handleAddCategory} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Category Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Broken Footpath Paver Tiles"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Assigned Department</label>
                <select
                  value={newCatDept}
                  onChange={(e) => setNewCatDept(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg"
                >
                  {departments.map((d) => (
                    <option key={d.id} value={d.id}>{d.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Target SLA (Hours)</label>
                <input
                  type="number"
                  min="6"
                  max="168"
                  value={newCatSla}
                  onChange={(e) => setNewCatSla(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl transition"
              >
                Register Category
              </button>
            </form>
          </div>

          {/* Categories List */}
          <div className="md:col-span-2 bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Active Municipal Categories ({categories.length})
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {categories.map((cat) => (
                <div key={cat.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-900">{cat.name}</span>
                    <span className="text-[10px] font-mono text-sky-800 bg-sky-100 px-1.5 py-0.5 rounded font-bold">
                      {cat.code}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 line-clamp-1">{cat.description}</p>
                  <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-200/60">
                    <span>{cat.departmentName}</span>
                    <span className="font-semibold text-amber-700">SLA: {cat.slaHours}h</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Free Data & Export Tools */}
      {activeTab === 'tools' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Download className="w-4 h-4 text-sky-600" />
              Exports & Data Deliverables
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Generate offline-compatible municipal reports and export project source code for submission.
            </p>

            <div className="space-y-2.5">
              <button
                type="button"
                onClick={onExportCsv}
                className="w-full flex items-center justify-between p-3 rounded-xl border border-sky-200 bg-sky-50 hover:bg-sky-100 text-sky-900 transition font-bold text-xs"
              >
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-sky-600" />
                  <span>Download Municipal Grievance Report (.CSV)</span>
                </div>
                <span>Export &rarr;</span>
              </button>

              <button
                type="button"
                onClick={onExportZip}
                className="w-full flex items-center justify-between p-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-800 transition font-bold text-xs"
              >
                <div className="flex items-center gap-2">
                  <Download className="w-4 h-4 text-slate-600" />
                  <span>Export Complete Source Code Bundle (.ZIP)</span>
                </div>
                <span>Export &rarr;</span>
              </button>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5 text-rose-700">
              <RotateCcw className="w-4 h-4 text-rose-600" />
              Demo Data Reset
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Restore the prototype to its default seeded state with initial sample complaints, realistic timeline events, and preconfigured accounts.
            </p>

            <button
              type="button"
              onClick={handleResetData}
              className="px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl font-bold text-xs transition flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Reset All to Seed Data
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
