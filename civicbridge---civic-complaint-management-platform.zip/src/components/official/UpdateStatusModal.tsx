import React, { useState } from 'react';
import { Complaint, ComplaintStatus, Role, User } from '../../types';
import { storage } from '../../services/storageService';
import {
  X,
  CheckCircle2,
  Clock,
  Shield,
  Upload,
  AlertCircle,
  Truck,
  Camera,
  Check
} from 'lucide-react';

interface UpdateStatusModalProps {
  complaint: Complaint | null;
  currentUser: User;
  isOpen: boolean;
  onClose: () => void;
  onUpdated: (updatedComplaint: Complaint) => void;
}

const COMMON_FIELD_TEAMS = [
  'Rapid Asphalt Paving Crew #3',
  'Road Maintenance Squad Alpha',
  'SWM Compactor Truck Fleet #12',
  'Sanitation & Debris Clearance Team',
  'WSSB Emergency Valve Isolation Squad',
  'Drinking Water Line Repair Unit 2',
  'Stormwater Drain Desilting Gang',
  'Electrical Luminaire Lineman Crew',
  'Tree Pruning & Emergency Clearance Squad'
];

const RESOLUTION_PROOF_SAMPLES = [
  {
    label: 'Repaired Smooth Asphalt Road',
    url: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=800&auto=format&fit=crop&q=80'
  },
  {
    label: 'Cleared Waste & Cleaned Dumpster',
    url: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=800&auto=format&fit=crop&q=80'
  },
  {
    label: 'Installed New Bright Streetlight LED',
    url: 'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=800&auto=format&fit=crop&q=80'
  },
  {
    label: 'Sealed & Safe Concrete Manhole Cover',
    url: 'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?w=800&auto=format&fit=crop&q=80'
  }
];

export const UpdateStatusModal: React.FC<UpdateStatusModalProps> = ({
  complaint,
  currentUser,
  isOpen,
  onClose,
  onUpdated
}) => {
  if (!isOpen || !complaint) return null;

  const [status, setStatus] = useState<ComplaintStatus>(
    complaint.status === 'resolved' ? 'resolved' :
    complaint.status === 'submitted' ? 'under_review' :
    complaint.status === 'under_review' ? 'assigned' :
    complaint.status === 'assigned' ? 'in_progress' : 'resolved'
  );

  const [remarks, setRemarks] = useState(
    complaint.officialRemarks || 'Inspected by ward team and scheduled for action.'
  );
  const [assignedTeam, setAssignedTeam] = useState(
    complaint.assignedTeam || COMMON_FIELD_TEAMS[0]
  );
  const [resolutionPhoto, setResolutionPhoto] = useState(
    complaint.resolutionPhoto || ''
  );
  const [rejectionReason, setRejectionReason] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files[0];
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setResolutionPhoto(reader.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const updated = storage.updateComplaintStatus(complaint.id, status, {
        actorName: currentUser.name,
        actorRole: currentUser.role,
        remarks: remarks.trim(),
        assignedOfficialId: currentUser.id,
        assignedOfficialName: currentUser.name,
        assignedTeam: status !== 'rejected' ? assignedTeam : undefined,
        resolutionPhoto: status === 'resolved' ? (resolutionPhoto || RESOLUTION_PROOF_SAMPLES[0].url) : undefined,
        rejectionReason: status === 'rejected' ? rejectionReason : undefined
      });

      setSubmitting(false);
      onUpdated(updated);
      onClose();
    } catch (err: any) {
      setSubmitting(false);
      alert(err.message || 'Failed to update status');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-blue-900 text-white p-5 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-300 flex items-center gap-1">
              <Shield className="w-3.5 h-3.5" />
              Official Redressal Action Desk
            </span>
            <h2 className="text-lg font-bold text-white mt-0.5">
              Update Status: {complaint.id}
            </h2>
            <p className="text-xs text-slate-300 truncate max-w-sm mt-0.5">
              {complaint.title}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Target Status Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Select New Stage
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {(
                [
                  { id: 'under_review', label: 'Under Review', color: 'border-amber-400 text-amber-800 bg-amber-50' },
                  { id: 'assigned', label: 'Assign Field Crew', color: 'border-blue-400 text-blue-800 bg-blue-50' },
                  { id: 'in_progress', label: 'In Progress', color: 'border-sky-400 text-sky-800 bg-sky-50' },
                  { id: 'resolved', label: 'Resolved (Done)', color: 'border-emerald-400 text-emerald-800 bg-emerald-50' },
                  { id: 'rejected', label: 'Reject / Close', color: 'border-rose-400 text-rose-800 bg-rose-50' }
                ] as const
              ).map((opt) => (
                <button
                  type="button"
                  key={opt.id}
                  onClick={() => setStatus(opt.id)}
                  className={`p-2 rounded-xl border text-xs font-bold text-center transition flex items-center justify-center gap-1 ${status === opt.id ? `${opt.color} ring-2 ring-sky-500/30` : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}
                >
                  {status === opt.id && <Check className="w-3.5 h-3.5 shrink-0" />}
                  <span>{opt.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Field Team Assignment (If assigned or in progress) */}
          {(status === 'assigned' || status === 'in_progress' || status === 'resolved') && (
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Truck className="w-3.5 h-3.5 text-sky-600" />
                Assigned Maintenance Squad / Contractor
              </label>
              <select
                value={assignedTeam}
                onChange={(e) => setAssignedTeam(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 font-medium"
              >
                {COMMON_FIELD_TEAMS.map((team, idx) => (
                  <option key={idx} value={team}>
                    {team}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Rejection Reason (If rejected) */}
          {status === 'rejected' && (
            <div>
              <label className="block text-xs font-bold text-rose-700 mb-1">
                Reason for Rejection / Invalidation
              </label>
              <select
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-rose-50 border border-rose-300 rounded-xl focus:ring-2 focus:ring-rose-500/20 text-rose-900 font-medium"
              >
                <option value="">Select reason...</option>
                <option value="Duplicate report for already tracked incident">Duplicate report for already tracked incident</option>
                <option value="Location falls outside municipal corporation jurisdiction">Location falls outside municipal jurisdiction</option>
                <option value="Private property / Non-civic infrastructure">Private property / Non-civic infrastructure</option>
                <option value="Insufficient visual evidence or unlocatable landmark">Insufficient visual evidence or unlocatable</option>
              </select>
            </div>
          )}

          {/* Resolution Proof Photo (If resolving) */}
          {status === 'resolved' && (
            <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-2">
              <span className="block text-[11px] font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-1">
                <Camera className="w-3.5 h-3.5 text-emerald-600" />
                Proof of Resolution (Mandatory for Certification)
              </span>
              <p className="text-[11px] text-slate-600">
                Attach inspection photo confirming completion:
              </p>

              {/* Sample Proof Photos */}
              <div className="grid grid-cols-2 gap-2">
                {RESOLUTION_PROOF_SAMPLES.map((sample, idx) => (
                  <button
                    type="button"
                    key={idx}
                    onClick={() => setResolutionPhoto(sample.url)}
                    className={`rounded-lg overflow-hidden border text-left p-1 bg-white transition ${resolutionPhoto === sample.url ? 'ring-2 ring-emerald-600 border-emerald-600' : 'border-slate-200 hover:border-emerald-300'}`}
                  >
                    <img src={sample.url} alt={sample.label} className="w-full h-12 object-cover rounded" />
                    <span className="block text-[10px] font-semibold text-slate-700 truncate mt-1">
                      {sample.label}
                    </span>
                  </button>
                ))}
              </div>

              {/* Or Upload Custom Proof */}
              <label className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer transition w-fit">
                <Upload className="w-3.5 h-3.5 text-emerald-600" />
                Upload Custom Photo Proof
                <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>
          )}

          {/* Official Remarks */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Official Inspector Remarks & Action Log
            </label>
            <textarea
              rows={3}
              required
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="Enter official assessment, materials dispatched, or completion remarks..."
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
          </div>

          {/* Submit */}
          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 text-slate-700 rounded-xl font-bold text-xs hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 bg-gradient-to-r from-sky-600 to-blue-700 text-white rounded-xl font-bold text-xs shadow-md shadow-sky-600/20 hover:from-sky-700 hover:to-blue-800 transition"
            >
              {submitting ? 'Updating...' : 'Commit Status & Notify Citizen'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
