import React, { useState } from 'react';
import { Complaint, Department, User, Ward } from '../../types';
import { LeafletMap } from '../common/LeafletMap';
import {
  Shield,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Truck,
  Filter,
  MapPin,
  ArrowRight,
  UserCheck,
  Send,
  Calendar,
  Layers,
  Sparkles
} from 'lucide-react';

interface OfficialDashboardProps {
  currentUser: User;
  complaints: Complaint[];
  departments: Department[];
  wards: Ward[];
  onOpenUpdateModal: (complaint: Complaint) => void;
  onSelectComplaint: (complaint: Complaint) => void;
}

export const OfficialDashboard: React.FC<OfficialDashboardProps> = ({
  currentUser,
  complaints,
  departments,
  wards,
  onOpenUpdateModal,
  onSelectComplaint
}) => {
  const [selectedWardFilter, setSelectedWardFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('action_needed');
  const [activeTab, setActiveTab] = useState<'queue' | 'map'>('queue');

  // Filter complaints relevant to official
  const myDeptComplaints = complaints.filter((c) => {
    // If official has department assigned, prioritize it, otherwise allow viewing all
    if (currentUser.departmentId && c.departmentId !== currentUser.departmentId && currentUser.role !== 'admin') {
      return false;
    }
    if (selectedWardFilter !== 'all' && c.wardId !== selectedWardFilter) {
      return false;
    }
    if (statusFilter === 'action_needed') {
      return c.status === 'submitted' || c.status === 'under_review' || c.status === 'assigned';
    }
    if (statusFilter === 'in_progress') {
      return c.status === 'in_progress';
    }
    if (statusFilter === 'resolved') {
      return c.status === 'resolved';
    }
    return true;
  });

  const urgentCount = myDeptComplaints.filter(c => c.priority === 'critical' || c.priority === 'high').length;
  const inProgressCount = myDeptComplaints.filter(c => c.status === 'in_progress').length;
  const resolvedCount = myDeptComplaints.filter(c => c.status === 'resolved').length;
  const pendingTriageCount = myDeptComplaints.filter(c => c.status === 'submitted' || c.status === 'under_review').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Official Profile & Status Bar */}
      <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-blue-900 rounded-2xl p-6 text-white shadow-lg border border-sky-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-extrabold text-lg shadow-md">
              {currentUser.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight">{currentUser.name}</h1>
                <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30">
                  Municipal Inspector
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Ward Officer Jurisdiction: <span className="text-cyan-300 font-semibold">{currentUser.wardId ? currentUser.wardId.replace('_', ' ').toUpperCase() : 'Central Municipal Zone'}</span>
                {' '}&bull; Dept: <span className="text-cyan-300 font-semibold">Roads & Public Works</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <button
              type="button"
              onClick={() => setActiveTab('queue')}
              className={`px-3 py-1.5 rounded-xl font-bold transition ${activeTab === 'queue' ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}
            >
              Action Queue ({myDeptComplaints.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('map')}
              className={`px-3 py-1.5 rounded-xl font-bold transition ${activeTab === 'map' ? 'bg-cyan-400 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}
            >
              GIS Ward Map
            </button>
          </div>
        </div>

        {/* Workload Metric Counters */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-sky-800/80">
          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Pending Triage
            </span>
            <span className="text-2xl font-black text-amber-300">{pendingTriageCount}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Requires assignment</span>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              High / Critical
            </span>
            <span className="text-2xl font-black text-rose-400">{urgentCount}</span>
            <span className="text-[10px] text-rose-300 block mt-0.5">Safety & Hazard alerts</span>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              In Field Repair
            </span>
            <span className="text-2xl font-black text-sky-300">{inProgressCount}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Crews deployed on-site</span>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Certified Resolved
            </span>
            <span className="text-2xl font-black text-emerald-300">{resolvedCount}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Closed with proof</span>
          </div>
        </div>
      </div>

      {/* Control Toolbar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1">Filter:</span>
          <button
            type="button"
            onClick={() => setStatusFilter('action_needed')}
            className={`px-3 py-1.5 rounded-lg font-bold transition shrink-0 ${statusFilter === 'action_needed' ? 'bg-amber-100 text-amber-900 border border-amber-300' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
          >
            Needs Action
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('in_progress')}
            className={`px-3 py-1.5 rounded-lg font-bold transition shrink-0 ${statusFilter === 'in_progress' ? 'bg-sky-100 text-sky-900 border border-sky-300' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
          >
            In Progress
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('resolved')}
            className={`px-3 py-1.5 rounded-lg font-bold transition shrink-0 ${statusFilter === 'resolved' ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
          >
            Resolved
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-lg font-bold transition shrink-0 ${statusFilter === 'all' ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
          >
            All Items
          </button>
        </div>

        <div className="w-full sm:w-64">
          <select
            value={selectedWardFilter}
            onChange={(e) => setSelectedWardFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl font-medium"
          >
            <option value="all">All Wards Coverage</option>
            {wards.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Content Area */}
      {activeTab === 'map' ? (
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3">
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
            <MapPin className="w-4 h-4 text-sky-600" />
            Jurisdiction GIS Map (Showing {myDeptComplaints.length} Grievance Markers)
          </h3>
          <LeafletMap
            mode="view_multiple"
            complaints={myDeptComplaints}
            onSelectComplaint={onSelectComplaint}
            className="h-[480px] w-full rounded-xl overflow-hidden border border-slate-200"
          />
        </div>
      ) : (
        <div className="space-y-4">
          {myDeptComplaints.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 shadow-sm space-y-2">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">No pending complaints in this queue!</h3>
              <p className="text-xs text-slate-500">
                All citizen reports for this filter have been processed or resolved.
              </p>
            </div>
          ) : (
            myDeptComplaints.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs hover:shadow-md transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-4 flex-1">
                  <div className="w-20 h-20 rounded-xl overflow-hidden bg-slate-100 shrink-0 border border-slate-200">
                    <img
                      src={item.photos[0]}
                      alt="Incident evidence"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs font-extrabold text-sky-900 bg-sky-100 px-2 py-0.5 rounded">
                        {item.id}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase ${
                        item.priority === 'critical' ? 'bg-rose-100 text-rose-800 border-rose-300' :
                        item.priority === 'high' ? 'bg-amber-100 text-amber-800 border-amber-300' :
                        'bg-sky-100 text-sky-800 border-sky-300'
                      }`}>
                        {item.priority}
                      </span>
                      <span className="text-xs font-bold text-slate-700">
                        {item.categoryName}
                      </span>
                      <span className="text-xs text-slate-400">
                        &bull; {item.wardName.split(' - ')[0]}
                      </span>
                    </div>

                    <h3
                      onClick={() => onSelectComplaint(item)}
                      className="font-bold text-slate-900 text-sm hover:text-sky-700 cursor-pointer transition line-clamp-1"
                    >
                      {item.title}
                    </h3>

                    <p className="text-xs text-slate-500 line-clamp-1">
                      {item.description}
                    </p>

                    <div className="flex items-center gap-3 text-[11px] text-slate-400 pt-1">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-sky-600" />
                        {item.address}
                      </span>
                      {item.assignedTeam && (
                        <span className="flex items-center gap-1 text-slate-600 font-medium">
                          <Truck className="w-3 h-3 text-amber-600" />
                          Crew: {item.assignedTeam}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                  <button
                    type="button"
                    onClick={() => onSelectComplaint(item)}
                    className="px-3.5 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-xl font-bold text-xs transition"
                  >
                    View Timeline
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenUpdateModal(item)}
                    className="px-4 py-2 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white rounded-xl font-bold text-xs shadow-xs transition flex items-center gap-1.5"
                  >
                    <Shield className="w-3.5 h-3.5" />
                    Update / Assign
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
