import React, { useState } from 'react';
import { User, Role, NotificationItem } from '../../types';
import {
  ShieldCheck,
  Bell,
  Search,
  User as UserIcon,
  LogOut,
  Sparkles,
  FileText,
  MapPin,
  CheckCircle2,
  Clock,
  Download,
  AlertCircle,
  Menu,
  X
} from 'lucide-react';

interface NavbarProps {
  currentUser: User;
  onSwitchUser: (userRole: Role) => void;
  onOpenAuthModal: () => void;
  onLogout: () => void;
  activeTab: 'home' | 'submit' | 'track' | 'official' | 'admin' | 'guide';
  setActiveTab: (tab: 'home' | 'submit' | 'track' | 'official' | 'admin' | 'guide') => void;
  notifications: NotificationItem[];
  onMarkNotificationsRead: () => void;
  onSelectComplaintId?: (id: string) => void;
  onExportCsv: () => void;
  onExportZip: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onSwitchUser,
  onOpenAuthModal,
  onLogout,
  activeTab,
  setActiveTab,
  notifications,
  onMarkNotificationsRead,
  onSelectComplaintId,
  onExportCsv,
  onExportZip
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [searchId, setSearchId] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const handleQuickSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchId.trim()) return;
    const cleanId = searchId.trim().toUpperCase();
    if (onSelectComplaintId) {
      onSelectComplaintId(cleanId);
    }
    setActiveTab('track');
    setSearchId('');
  };

  const roleBadgeColors: Record<Role, string> = {
    citizen: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    official: 'bg-amber-50 text-amber-700 border-amber-200',
    admin: 'bg-purple-50 text-purple-700 border-purple-200'
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top Academic Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-blue-900 text-white text-xs px-4 py-1.5 flex flex-wrap items-center justify-between gap-2 border-b border-sky-800">
        <div className="flex items-center gap-2">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
          </span>
          <span className="font-semibold text-cyan-300">College Capstone Project:</span>
          <span className="text-slate-300 hidden sm:inline">100% Free Autonomous Civic Platform (Zero Paid APIs Required)</span>
        </div>

        {/* Quick Demo Switcher */}
        <div className="flex items-center gap-1.5 text-[11px]">
          <span className="text-slate-300 font-medium hidden md:inline">Quick Switch Demo:</span>
          <button
            type="button"
            onClick={() => onSwitchUser('citizen')}
            className={`px-2 py-0.5 rounded transition font-medium ${currentUser.role === 'citizen' ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}
          >
            Citizen
          </button>
          <button
            type="button"
            onClick={() => onSwitchUser('official')}
            className={`px-2 py-0.5 rounded transition font-medium ${currentUser.role === 'official' ? 'bg-amber-400 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}
          >
            Official
          </button>
          <button
            type="button"
            onClick={() => onSwitchUser('admin')}
            className={`px-2 py-0.5 rounded transition font-medium ${currentUser.role === 'admin' ? 'bg-purple-400 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}
          >
            Admin
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('guide')}
            className="ml-2 text-cyan-300 hover:text-white underline font-medium flex items-center gap-1"
          >
            <FileText className="w-3 h-3" />
            Project Guide
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('home')}
              className="flex items-center gap-2.5 text-left group"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-600 via-blue-600 to-cyan-500 flex items-center justify-center text-white shadow-md shadow-sky-500/20 group-hover:scale-105 transition-transform">
                <ShieldCheck className="w-6 h-6 text-white stroke-[2.2]" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-slate-900 via-sky-900 to-blue-700 bg-clip-text text-transparent">
                    CivicBridge
                  </span>
                  <span className="text-[10px] font-bold uppercase tracking-wider bg-sky-100 text-sky-800 px-1.5 py-0.5 rounded">
                    OpenGov
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 font-medium -mt-0.5 hidden sm:block">
                  Civic Grievance & AI Routing
                </p>
              </div>
            </button>
          </div>

          {/* Quick Search for Complaint ID */}
          <form onSubmit={handleQuickSearch} className="hidden md:flex items-center relative max-w-xs w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
            <input
              type="text"
              placeholder="Track Complaint (e.g. CB-2026-1042)..."
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-sky-500/30 focus:border-sky-500 transition"
            />
          </form>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 text-sm font-semibold text-slate-600">
            <button
              onClick={() => setActiveTab('home')}
              className={`px-3 py-2 rounded-lg transition ${activeTab === 'home' ? 'text-sky-700 bg-sky-50' : 'hover:text-slate-900 hover:bg-slate-50'}`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('submit')}
              className={`px-3 py-2 rounded-lg transition flex items-center gap-1.5 ${activeTab === 'submit' ? 'text-sky-700 bg-sky-50' : 'hover:text-slate-900 hover:bg-slate-50'}`}
            >
              <Sparkles className="w-4 h-4 text-cyan-600" />
              Report Issue
            </button>
            <button
              onClick={() => setActiveTab('track')}
              className={`px-3 py-2 rounded-lg transition ${activeTab === 'track' ? 'text-sky-700 bg-sky-50' : 'hover:text-slate-900 hover:bg-slate-50'}`}
            >
              Track Grievances
            </button>

            {/* Official Portal tab */}
            {(currentUser.role === 'official' || currentUser.role === 'admin') && (
              <button
                onClick={() => setActiveTab('official')}
                className={`px-3 py-2 rounded-lg transition flex items-center gap-1 ${activeTab === 'official' ? 'text-amber-700 bg-amber-50' : 'hover:text-slate-900 hover:bg-slate-50'}`}
              >
                Official Desk
              </button>
            )}

            {/* Admin Portal tab */}
            {currentUser.role === 'admin' && (
              <button
                onClick={() => setActiveTab('admin')}
                className={`px-3 py-2 rounded-lg transition flex items-center gap-1 ${activeTab === 'admin' ? 'text-purple-700 bg-purple-50' : 'hover:text-slate-900 hover:bg-slate-50'}`}
              >
                Admin Control
              </button>
            )}
          </nav>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-2">
            {/* Notifications Popover */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setShowNotifications(!showNotifications);
                  if (!showNotifications && unreadCount > 0) {
                    onMarkNotificationsRead();
                  }
                }}
                className="relative p-2 text-slate-600 hover:text-sky-600 rounded-lg hover:bg-slate-100 transition"
                title="Notifications"
              >
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white shadow-xs">
                    {unreadCount}
                  </span>
                )}
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-xl shadow-xl border border-slate-200 z-50 p-3">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100">
                    <span className="font-bold text-xs text-slate-800 uppercase tracking-wider">
                      Notifications & Alerts
                    </span>
                    <button
                      type="button"
                      onClick={onMarkNotificationsRead}
                      className="text-[11px] text-sky-600 hover:underline font-medium"
                    >
                      Mark all as read
                    </button>
                  </div>

                  <div className="max-h-72 overflow-y-auto space-y-2">
                    {notifications.length === 0 ? (
                      <p className="text-xs text-slate-400 text-center py-4">No notifications yet.</p>
                    ) : (
                      notifications.slice(0, 8).map((notif) => (
                        <div
                          key={notif.id}
                          onClick={() => {
                            if (notif.complaintId && onSelectComplaintId) {
                              onSelectComplaintId(notif.complaintId);
                              setActiveTab('track');
                            }
                            setShowNotifications(false);
                          }}
                          className={`p-2.5 rounded-lg border text-xs cursor-pointer transition ${notif.isRead ? 'bg-slate-50/70 border-slate-100 hover:bg-slate-100' : 'bg-sky-50/80 border-sky-100 hover:bg-sky-100'}`}
                        >
                          <div className="flex items-start justify-between gap-1">
                            <span className="font-semibold text-slate-900">{notif.title}</span>
                            <span className="text-[10px] text-slate-400 whitespace-nowrap">
                              {new Date(notif.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                          <p className="text-slate-600 text-[11px] mt-0.5 line-clamp-2">{notif.message}</p>
                          {notif.complaintId && (
                            <span className="inline-block mt-1 font-mono text-[10px] text-sky-700 bg-sky-100/80 px-1.5 py-0.2 rounded font-semibold">
                              {notif.complaintId}
                            </span>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Current User Pill / Switcher */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center gap-2 p-1 pl-2 rounded-xl border border-slate-200 bg-slate-50/80 hover:bg-slate-100 transition text-left"
              >
                <div className="text-right hidden sm:block">
                  <span className="block text-xs font-bold text-slate-800 leading-tight">
                    {currentUser.name}
                  </span>
                  <span className={`inline-block text-[10px] font-bold px-1.5 py-0.2 rounded border ${roleBadgeColors[currentUser.role]}`}>
                    {currentUser.role.toUpperCase()}
                  </span>
                </div>
                <div className="w-8 h-8 rounded-lg bg-sky-600 text-white font-bold flex items-center justify-center text-xs shadow-xs">
                  {currentUser.name.charAt(0)}
                </div>
              </button>

              {showUserMenu && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-200 z-50 p-3">
                  <div className="pb-3 border-b border-slate-100">
                    <p className="text-xs font-bold text-slate-900">{currentUser.name}</p>
                    <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>
                    <span className={`inline-block mt-1.5 text-[10px] font-bold px-2 py-0.5 rounded border capitalize ${roleBadgeColors[currentUser.role]}`}>
                      Role: {currentUser.role}
                    </span>
                  </div>

                  <div className="py-2 space-y-1">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2 py-1">
                      Quick Switch Role
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        onSwitchUser('citizen');
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-2 py-1.5 text-xs text-slate-700 hover:bg-slate-100 rounded-md font-medium flex items-center justify-between"
                    >
                      <span>Citizen (Aarav Sharma)</span>
                      {currentUser.role === 'citizen' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onSwitchUser('official');
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-2 py-1.5 text-xs text-slate-700 hover:bg-slate-100 rounded-md font-medium flex items-center justify-between"
                    >
                      <span>Official (Inspector Vikram)</span>
                      {currentUser.role === 'official' && <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onSwitchUser('admin');
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-2 py-1.5 text-xs text-slate-700 hover:bg-slate-100 rounded-md font-medium flex items-center justify-between"
                    >
                      <span>Admin (Director Sunita)</span>
                      {currentUser.role === 'admin' && <CheckCircle2 className="w-3.5 h-3.5 text-purple-600" />}
                    </button>
                  </div>

                  <div className="pt-2 border-t border-slate-100 space-y-1">
                    <button
                      type="button"
                      onClick={() => {
                        onExportCsv();
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-2 py-1.5 text-xs text-slate-700 hover:bg-slate-100 rounded-md font-medium flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5 text-sky-600" />
                      Export Complaints CSV
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onExportZip();
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-2 py-1.5 text-xs text-slate-700 hover:bg-slate-100 rounded-md font-medium flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5 text-cyan-600" />
                      Export Project ZIP
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onOpenAuthModal();
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-2 py-1.5 text-xs text-sky-700 hover:bg-sky-50 rounded-md font-medium flex items-center gap-1.5"
                    >
                      <UserIcon className="w-3.5 h-3.5" />
                      Sign In with New Account
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Mobile menu toggle button */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Dropdown Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-2 shadow-lg">
          <form onSubmit={handleQuickSearch} className="flex items-center relative w-full mb-3">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
            <input
              type="text"
              placeholder="Track Complaint (e.g. CB-2026-1042)..."
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg"
            />
          </form>

          <button
            onClick={() => { setActiveTab('home'); setMobileMenuOpen(false); }}
            className={`w-full text-left px-3 py-2 rounded-lg text-sm font-semibold ${activeTab === 'home' ? 'text-sky-700 bg-sky-50' : 'text-slate-700'}`}
          >
            Overview
          </button>
          <button
            onClick={() => { setActiveTab('submit'); setMobileMenuOpen(false); }}
            className={`w-full text-left px-3 py-2 rounded-lg text-sm font-semibold flex items-center gap-2 ${activeTab === 'submit' ? 'text-sky-700 bg-sky-50' : 'text-slate-700'}`}
          >
            <Sparkles className="w-4 h-4 text-cyan-600" />
            Report Civic Issue
          </button>
          <button
            onClick={() => { setActiveTab('track'); setMobileMenuOpen(false); }}
            className={`w-full text-left px-3 py-2 rounded-lg text-sm font-semibold ${activeTab === 'track' ? 'text-sky-700 bg-sky-50' : 'text-slate-700'}`}
          >
            Track Grievances
          </button>
          {(currentUser.role === 'official' || currentUser.role === 'admin') && (
            <button
              onClick={() => { setActiveTab('official'); setMobileMenuOpen(false); }}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm font-semibold ${activeTab === 'official' ? 'text-amber-700 bg-amber-50' : 'text-slate-700'}`}
            >
              Official Desk
            </button>
          )}
          {currentUser.role === 'admin' && (
            <button
              onClick={() => { setActiveTab('admin'); setMobileMenuOpen(false); }}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm font-semibold ${activeTab === 'admin' ? 'text-purple-700 bg-purple-50' : 'text-slate-700'}`}
            >
              Admin Control
            </button>
          )}
          <button
            onClick={() => { setActiveTab('guide'); setMobileMenuOpen(false); }}
            className={`w-full text-left px-3 py-2 rounded-lg text-sm font-semibold flex items-center gap-1.5 ${activeTab === 'guide' ? 'text-sky-700 bg-sky-50' : 'text-slate-700'}`}
          >
            <FileText className="w-4 h-4 text-sky-600" />
            Project Guide & Run Instructions
          </button>
        </div>
      )}
    </header>
  );
};
