import { Category, Department, User, Ward, Complaint, NotificationItem } from '../types';

export const INITIAL_DEPARTMENTS: Department[] = [
  {
    id: 'dept_roads',
    name: 'Road Infrastructure & Public Works',
    code: 'PWD-RD',
    contactEmail: 'pwd.roads@civicbridge.org',
    phone: '+1 (555) 234-7001',
    headName: 'Er. Rajesh Deshmukh'
  },
  {
    id: 'dept_sanitation',
    name: 'Solid Waste Management & Sanitation',
    code: 'SWM-SAN',
    contactEmail: 'sanitation@civicbridge.org',
    phone: '+1 (555) 234-7002',
    headName: 'Dr. Meenakshi Sundaram'
  },
  {
    id: 'dept_water',
    name: 'Water Supply & Sewerage Board',
    code: 'WSSB-WTR',
    contactEmail: 'water.works@civicbridge.org',
    phone: '+1 (555) 234-7003',
    headName: 'K. S. Narayanan'
  },
  {
    id: 'dept_electrical',
    name: 'Electrical Infrastructure & Street Lighting',
    code: 'ELEC-LGT',
    contactEmail: 'electrical@civicbridge.org',
    phone: '+1 (555) 234-7004',
    headName: 'Anil Kumar Verma'
  },
  {
    id: 'dept_parks',
    name: 'Parks, Lakes & Urban Forestry',
    code: 'PLUF-ENV',
    contactEmail: 'parks.urban@civicbridge.org',
    phone: '+1 (555) 234-7005',
    headName: 'Smt. Priya Sen'
  }
];

export const INITIAL_WARDS: Ward[] = [
  {
    id: 'ward_101',
    number: 101,
    name: 'Ward 101 - Central City & Civic Plaza',
    zone: 'Central Zone',
    councillor: 'Rameshwar Gupta',
    centerLat: 12.9716,
    centerLng: 77.5946
  },
  {
    id: 'ward_102',
    number: 102,
    name: 'Ward 102 - University Campus & Tech Enclave',
    zone: 'North Zone',
    councillor: 'Anita V. Roy',
    centerLat: 12.9854,
    centerLng: 77.6050
  },
  {
    id: 'ward_103',
    number: 103,
    name: 'Ward 103 - Metro Station & Commercial Market',
    zone: 'East Zone',
    councillor: 'Mohammad Farooq',
    centerLat: 12.9650,
    centerLng: 77.6180
  },
  {
    id: 'ward_104',
    number: 104,
    name: 'Ward 104 - Lakeside Greens & Residency',
    zone: 'South Zone',
    councillor: 'Deepika Kulkarni',
    centerLat: 12.9520,
    centerLng: 77.5830
  },
  {
    id: 'ward_105',
    number: 105,
    name: 'Ward 105 - West Industrial Estate & Rail Link',
    zone: 'West Zone',
    councillor: 'Gopal Krishnan',
    centerLat: 12.9780,
    centerLng: 77.5610
  }
];

export const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'cat_potholes',
    name: 'Potholes & Damaged Roads',
    code: 'ROADS',
    departmentId: 'dept_roads',
    departmentName: 'Road Infrastructure & Public Works',
    iconName: 'Construction',
    description: 'Potholes, surface erosion, damaged speed breakers, missing asphalt, and road craters.',
    defaultPriority: 'medium',
    slaHours: 48
  },
  {
    id: 'cat_garbage',
    name: 'Garbage & Solid Waste',
    code: 'WASTE',
    departmentId: 'dept_sanitation',
    departmentName: 'Solid Waste Management & Sanitation',
    iconName: 'Trash2',
    description: 'Overflowing dustbins, uncollected household waste, black spot dumping, and litter piles.',
    defaultPriority: 'medium',
    slaHours: 24
  },
  {
    id: 'cat_water',
    name: 'Water Supply & Leakage',
    code: 'WATER',
    departmentId: 'dept_water',
    departmentName: 'Water Supply & Sewerage Board',
    iconName: 'Droplets',
    description: 'Underground pipeline bursts, leaking municipal valves, contaminated tap water, zero supply.',
    defaultPriority: 'high',
    slaHours: 24
  },
  {
    id: 'cat_drainage',
    name: 'Drainage & Sewage',
    code: 'DRAIN',
    departmentId: 'dept_water',
    departmentName: 'Water Supply & Sewerage Board',
    iconName: 'Waves',
    description: 'Open manholes, blocked roadside storm gutters, sewage backflow, foul wastewater puddles.',
    defaultPriority: 'high',
    slaHours: 24
  },
  {
    id: 'cat_streetlights',
    name: 'Streetlights & Electrical',
    code: 'LIGHT',
    departmentId: 'dept_electrical',
    departmentName: 'Electrical Infrastructure & Street Lighting',
    iconName: 'Lightbulb',
    description: 'Flickering or fused streetlamps, bent poles, hanging live wires, dark streets at night.',
    defaultPriority: 'medium',
    slaHours: 36
  },
  {
    id: 'cat_sanitation',
    name: 'Sanitation & Public Health',
    code: 'SAN',
    departmentId: 'dept_sanitation',
    departmentName: 'Solid Waste Management & Sanitation',
    iconName: 'ShieldAlert',
    description: 'Uncleaned public toilets, animal carcasses, mosquito breeding stagnant pools, fogging needs.',
    defaultPriority: 'medium',
    slaHours: 24
  },
  {
    id: 'cat_parks',
    name: 'Parks & Fallen Trees',
    code: 'PARKS',
    departmentId: 'dept_parks',
    departmentName: 'Parks, Lakes & Urban Forestry',
    iconName: 'Trees',
    description: 'Storm-felled tree branches blocking lanes, broken playground equipment, park upkeep.',
    defaultPriority: 'low',
    slaHours: 72
  },
  {
    id: 'cat_traffic',
    name: 'Traffic & Encroachment',
    code: 'TRAFFIC',
    departmentId: 'dept_roads',
    departmentName: 'Road Infrastructure & Public Works',
    iconName: 'AlertTriangle',
    description: 'Broken traffic signal, missing road signs, sidewalk encroachment blocking pedestrians.',
    defaultPriority: 'medium',
    slaHours: 48
  }
];

export const DEMO_USERS: User[] = [
  {
    id: 'usr_citizen_aarav',
    name: 'Aarav Sharma',
    email: 'citizen@civicbridge.org',
    role: 'citizen',
    phone: '+1 (555) 789-0123',
    wardId: 'ward_101',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    createdAt: '2026-01-10T09:00:00Z'
  },
  {
    id: 'usr_official_vikram',
    name: 'Inspector Vikram Patel',
    email: 'official@civicbridge.org',
    role: 'official',
    phone: '+1 (555) 890-4567',
    departmentId: 'dept_roads',
    wardId: 'ward_101',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    createdAt: '2025-11-15T08:30:00Z'
  },
  {
    id: 'usr_admin_sunita',
    name: 'Director Sunita Rao',
    email: 'admin@civicbridge.org',
    role: 'admin',
    phone: '+1 (555) 901-2345',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    createdAt: '2025-08-01T10:00:00Z'
  }
];

export const SAMPLE_COMPLAINT_PHOTOS = [
  {
    label: 'Deep Pothole (Roadway)',
    url: 'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=800&auto=format&fit=crop&q=80',
    category: 'cat_potholes'
  },
  {
    label: 'Overflowing Garbage Bin',
    url: 'https://images.unsplash.com/photo-1605600659908-0ef719419d41?w=800&auto=format&fit=crop&q=80',
    category: 'cat_garbage'
  },
  {
    label: 'Water Main Leakage',
    url: 'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?w=800&auto=format&fit=crop&q=80',
    category: 'cat_water'
  },
  {
    label: 'Dark Streetlight Pole',
    url: 'https://images.unsplash.com/photo-1509114397022-ed747cca3f65?w=800&auto=format&fit=crop&q=80',
    category: 'cat_streetlights'
  },
  {
    label: 'Open Manhole on Sidewalk',
    url: 'https://images.unsplash.com/photo-1541888946425-d0fbb186c5f7?w=800&auto=format&fit=crop&q=80',
    category: 'cat_drainage'
  }
];

export const INITIAL_COMPLAINTS: Complaint[] = [
  {
    id: 'CB-2026-1042',
    title: 'Severe crater pothole near City College Gate 2',
    description: 'A deep pothole of roughly 1.5 feet diameter has developed directly outside College Gate 2 on 4th Cross. Two two-wheelers skidded yesterday during evening rain. Needs urgent hot-mix asphalt patching before students commute tomorrow morning.',
    categoryId: 'cat_potholes',
    categoryName: 'Potholes & Damaged Roads',
    departmentId: 'dept_roads',
    departmentName: 'Road Infrastructure & Public Works',
    wardId: 'ward_101',
    wardName: 'Ward 101 - Central City & Civic Plaza',
    priority: 'high',
    status: 'in_progress',
    citizenId: 'usr_citizen_aarav',
    citizenName: 'Aarav Sharma',
    citizenEmail: 'citizen@civicbridge.org',
    citizenPhone: '+1 (555) 789-0123',
    address: 'Opposite City College Gate 2, 4th Cross Road, Ward 101',
    coordinates: {
      lat: 12.9722,
      lng: 77.5951
    },
    photos: [
      'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=800&auto=format&fit=crop&q=80'
    ],
    assignedOfficialId: 'usr_official_vikram',
    assignedOfficialName: 'Inspector Vikram Patel',
    assignedTeam: 'Rapid Asphalt Paving Crew #3',
    officialRemarks: 'Site inspected on 14th morning. Traffic barricades placed. Crew dispatched with cold-mix compound and roller machinery.',
    aiSuggestion: {
      categoryId: 'cat_potholes',
      categoryName: 'Potholes & Damaged Roads',
      confidence: 0.94,
      suggestedPriority: 'high',
      matchedKeywords: ['pothole', 'crater', 'two-wheelers skidded', 'asphalt'],
      reasoning: 'Identified high hazard risk keywords [pothole, crater, skidded] matching Road Infrastructure.',
      engine: 'local_rule_nlp'
    },
    timeline: [
      {
        id: 'tl_1042_1',
        status: 'submitted',
        title: 'Complaint Registered by Citizen',
        actorName: 'Aarav Sharma',
        actorRole: 'citizen',
        timestamp: '2026-10-12T14:20:00Z',
        remarks: 'Filed via CivicBridge portal with geo-tagged coordinates.'
      },
      {
        id: 'tl_1042_2',
        status: 'under_review',
        title: 'Municipal Intake Verification',
        actorName: 'Control Desk Automated System',
        actorRole: 'admin',
        timestamp: '2026-10-12T14:22:00Z',
        remarks: 'AI classifier routed case to Road Infrastructure. SLA counter initialized.'
      },
      {
        id: 'tl_1042_3',
        status: 'assigned',
        title: 'Assigned to Ward Inspector',
        actorName: 'Director Sunita Rao',
        actorRole: 'admin',
        timestamp: '2026-10-12T15:05:00Z',
        remarks: 'Assigned to Ward 101 Inspector Vikram Patel for immediate site assessment.'
      },
      {
        id: 'tl_1042_4',
        status: 'in_progress',
        title: 'Work In Progress - Crew Dispatched',
        actorName: 'Inspector Vikram Patel',
        actorRole: 'official',
        timestamp: '2026-10-13T09:30:00Z',
        remarks: 'Rapid Asphalt Paving Crew #3 mobilized with asphalt patch kit.'
      }
    ],
    createdAt: '2026-10-12T14:20:00Z',
    updatedAt: '2026-10-13T09:30:00Z'
  },
  {
    id: 'CB-2026-1088',
    title: 'Overflowing commercial garbage dumpster creating public health risk',
    description: 'The community dumpster at Market Junction has not been emptied for 4 days. Waste is spilling over 15 meters across the pedestrian walkway, attracting stray animals and generating a severe foul odor near the vegetable stalls.',
    categoryId: 'cat_garbage',
    categoryName: 'Garbage & Solid Waste',
    departmentId: 'dept_sanitation',
    departmentName: 'Solid Waste Management & Sanitation',
    wardId: 'ward_103',
    wardName: 'Ward 103 - Metro Station & Commercial Market',
    priority: 'high',
    status: 'under_review',
    citizenId: 'usr_citizen_aarav',
    citizenName: 'Aarav Sharma',
    citizenEmail: 'citizen@civicbridge.org',
    citizenPhone: '+1 (555) 789-0123',
    address: 'Near Old Vegetable Market, Station Road Corner, Ward 103',
    coordinates: {
      lat: 12.9658,
      lng: 77.6192
    },
    photos: [
      'https://images.unsplash.com/photo-1605600659908-0ef719419d41?w=800&auto=format&fit=crop&q=80'
    ],
    officialRemarks: 'Solid waste scheduler notified. Compactor truck rerouting scheduled for afternoon run.',
    aiSuggestion: {
      categoryId: 'cat_garbage',
      categoryName: 'Garbage & Solid Waste',
      confidence: 0.95,
      suggestedPriority: 'high',
      matchedKeywords: ['garbage', 'dumpster', 'waste', 'foul odor', 'stray animals'],
      reasoning: 'Detected high-density waste accumulation and sanitation hazard keywords.',
      engine: 'local_rule_nlp'
    },
    timeline: [
      {
        id: 'tl_1088_1',
        status: 'submitted',
        title: 'Complaint Registered by Citizen',
        actorName: 'Aarav Sharma',
        actorRole: 'citizen',
        timestamp: '2026-10-13T08:15:00Z',
        remarks: 'Submitted with photo proof of uncollected waste.'
      },
      {
        id: 'tl_1088_2',
        status: 'under_review',
        title: 'Reviewed by Sanitation Control Desk',
        actorName: 'Dr. Meenakshi Sundaram',
        actorRole: 'admin',
        timestamp: '2026-10-13T09:00:00Z',
        remarks: 'Ward 103 sanitation supervisor alerted for clearing backlog.'
      }
    ],
    createdAt: '2026-10-13T08:15:00Z',
    updatedAt: '2026-10-13T09:00:00Z'
  },
  {
    id: 'CB-2026-1015',
    title: 'Drinking water pipeline rupture flooding 7th Cross roadway',
    description: 'Underground drinking water main has ruptured with high pressure. Clear drinking water is gushing onto the road, entering the basement of building #42 and eroding the sidewalk edge. Immediate shutoff needed.',
    categoryId: 'cat_water',
    categoryName: 'Water Supply & Leakage',
    departmentId: 'dept_water',
    departmentName: 'Water Supply & Sewerage Board',
    wardId: 'ward_101',
    wardName: 'Ward 101 - Central City & Civic Plaza',
    priority: 'critical',
    status: 'assigned',
    citizenId: 'usr_citizen_aarav',
    citizenName: 'Aarav Sharma',
    citizenEmail: 'citizen@civicbridge.org',
    citizenPhone: '+1 (555) 789-0123',
    address: 'Near Building 42, 7th Cross, Central Sector, Ward 101',
    coordinates: {
      lat: 12.9735,
      lng: 77.5912
    },
    photos: [
      'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?w=800&auto=format&fit=crop&q=80'
    ],
    assignedOfficialId: 'usr_official_vikram',
    assignedOfficialName: 'Inspector Vikram Patel',
    assignedTeam: 'WSSB Emergency Valve Isolation Squad',
    officialRemarks: 'Upstream feeder valve 4-B temporarily locked out to prevent potable water loss. Excavation backhoe requested.',
    aiSuggestion: {
      categoryId: 'cat_water',
      categoryName: 'Water Supply & Leakage',
      confidence: 0.96,
      suggestedPriority: 'critical',
      matchedKeywords: ['water', 'pipeline', 'ruptured', 'gushing water', 'emergency'],
      reasoning: 'Critical water main burst detected with high volume wastage indicator.',
      engine: 'local_rule_nlp'
    },
    timeline: [
      {
        id: 'tl_1015_1',
        status: 'submitted',
        title: 'Emergency Complaint Filed',
        actorName: 'Aarav Sharma',
        actorRole: 'citizen',
        timestamp: '2026-10-13T16:45:00Z',
        remarks: 'Flagged as critical water infrastructure disruption.'
      },
      {
        id: 'tl_1015_2',
        status: 'under_review',
        title: 'Immediate AI Severity Escalation',
        actorName: 'CivicBridge Engine',
        actorRole: 'admin',
        timestamp: '2026-10-13T16:46:00Z',
        remarks: 'Priority escalated to CRITICAL due to potable water loss.'
      },
      {
        id: 'tl_1015_3',
        status: 'assigned',
        title: 'Assigned to Emergency Squad',
        actorName: 'Director Sunita Rao',
        actorRole: 'admin',
        timestamp: '2026-10-13T17:10:00Z',
        remarks: 'Forwarded directly to Ward 101 emergency team on duty.'
      }
    ],
    createdAt: '2026-10-13T16:45:00Z',
    updatedAt: '2026-10-13T17:10:00Z'
  },
  {
    id: 'CB-2026-0972',
    title: 'Broken streetlight pole causing dark accident blackspot at junction',
    description: 'Streetlight fixture on pole #SL-101-44 has been dead for 10 days. The blind curve is pitch dark at night and pedestrians crossing towards the bus terminal have faced near-misses with speeding vehicles.',
    categoryId: 'cat_streetlights',
    categoryName: 'Streetlights & Electrical',
    departmentId: 'dept_electrical',
    departmentName: 'Electrical Infrastructure & Street Lighting',
    wardId: 'ward_101',
    wardName: 'Ward 101 - Central City & Civic Plaza',
    priority: 'medium',
    status: 'resolved',
    citizenId: 'usr_citizen_aarav',
    citizenName: 'Aarav Sharma',
    citizenEmail: 'citizen@civicbridge.org',
    citizenPhone: '+1 (555) 789-0123',
    address: 'Corner of 2nd Main and Nehru Ring Road, Ward 101',
    coordinates: {
      lat: 12.9705,
      lng: 77.5985
    },
    photos: [
      'https://images.unsplash.com/photo-1509114397022-ed747cca3f65?w=800&auto=format&fit=crop&q=80'
    ],
    resolutionPhoto: 'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=800&auto=format&fit=crop&q=80',
    assignedOfficialId: 'usr_official_vikram',
    assignedOfficialName: 'Inspector Vikram Patel',
    assignedTeam: 'Electrical Unit #1',
    officialRemarks: 'Defective LED driver and ballast replaced with energy efficient 90W Philips luminaire. Pole earthing tested and certified safe.',
    resolutionRemarks: 'New LED fixture installed and verified functional by night patrol on 13 Oct 2026 at 20:30.',
    citizenRating: 5,
    citizenFeedback: 'Thank you! The light was fixed within 36 hours and the junction is completely safe now.',
    aiSuggestion: {
      categoryId: 'cat_streetlights',
      categoryName: 'Streetlights & Electrical',
      confidence: 0.92,
      suggestedPriority: 'medium',
      matchedKeywords: ['streetlight', 'pole', 'dark', 'light fixture'],
      reasoning: 'Electrical street lighting fault recognized with location pole tag.',
      engine: 'local_rule_nlp'
    },
    timeline: [
      {
        id: 'tl_0972_1',
        status: 'submitted',
        title: 'Report Lodged',
        actorName: 'Aarav Sharma',
        actorRole: 'citizen',
        timestamp: '2026-10-11T19:00:00Z',
        remarks: 'Reported non-functioning pole #SL-101-44.'
      },
      {
        id: 'tl_0972_2',
        status: 'under_review',
        title: 'Verified and Logged',
        actorName: 'Anil Kumar Verma',
        actorRole: 'official',
        timestamp: '2026-10-12T08:30:00Z',
        remarks: 'Confirmed asset record in municipal lighting grid.'
      },
      {
        id: 'tl_0972_3',
        status: 'assigned',
        title: 'Assigned to Lighting Technician',
        actorName: 'Anil Kumar Verma',
        actorRole: 'official',
        timestamp: '2026-10-12T10:00:00Z',
        remarks: 'Assigned to Electrical Unit #1 with replacement luminaire.'
      },
      {
        id: 'tl_0972_4',
        status: 'in_progress',
        title: 'Technician on Site',
        actorName: 'Ravi Teja (Lineman)',
        actorRole: 'official',
        timestamp: '2026-10-13T14:00:00Z',
        remarks: 'Hydraulic ladder truck deployed.'
      },
      {
        id: 'tl_0972_5',
        status: 'resolved',
        title: 'Issue Resolved & Certified',
        actorName: 'Inspector Vikram Patel',
        actorRole: 'official',
        timestamp: '2026-10-13T20:45:00Z',
        remarks: 'Work verified. High-resolution proof photo attached.',
        attachmentUrl: 'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=800&auto=format&fit=crop&q=80'
      }
    ],
    createdAt: '2026-10-11T19:00:00Z',
    updatedAt: '2026-10-13T20:45:00Z',
    resolvedAt: '2026-10-13T20:45:00Z'
  },
  {
    id: 'CB-2026-1104',
    title: 'Uncovered manhole on busy pedestrian footway',
    description: 'Concrete manhole cover has broken and caved in, leaving a gaping 3-foot deep opening right along the sidewalk next to the high school entrance. High risk for falling schoolchildren.',
    categoryId: 'cat_drainage',
    categoryName: 'Drainage & Sewage',
    departmentId: 'dept_water',
    departmentName: 'Water Supply & Sewerage Board',
    wardId: 'ward_102',
    wardName: 'Ward 102 - University Campus & Tech Enclave',
    priority: 'critical',
    status: 'submitted',
    citizenId: 'usr_citizen_aarav',
    citizenName: 'Aarav Sharma',
    citizenEmail: 'citizen@civicbridge.org',
    citizenPhone: '+1 (555) 789-0123',
    address: 'Near Government High School Entrance, University Road, Ward 102',
    coordinates: {
      lat: 12.9860,
      lng: 77.6045
    },
    photos: [
      'https://images.unsplash.com/photo-1541888946425-d0fbb186c5f7?w=800&auto=format&fit=crop&q=80'
    ],
    aiSuggestion: {
      categoryId: 'cat_drainage',
      categoryName: 'Drainage & Sewage',
      confidence: 0.97,
      suggestedPriority: 'critical',
      matchedKeywords: ['open manhole', 'caved in', 'schoolchildren', 'falling'],
      reasoning: 'Critical danger to pedestrians; open drainage shaft near academic institution.',
      engine: 'local_rule_nlp'
    },
    timeline: [
      {
        id: 'tl_1104_1',
        status: 'submitted',
        title: 'Emergency Complaint Lodged',
        actorName: 'Aarav Sharma',
        actorRole: 'citizen',
        timestamp: '2026-10-14T05:30:00Z',
        remarks: 'Reported with GPS accuracy.'
      }
    ],
    createdAt: '2026-10-14T05:30:00Z',
    updatedAt: '2026-10-14T05:30:00Z'
  }
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif_1',
    roleTarget: 'all',
    title: 'Welcome to CivicBridge',
    message: 'CivicBridge is live! Report civic grievances, track status updates with real-time audit logs, and inspect official progress.',
    type: 'alert',
    isRead: false,
    createdAt: '2026-10-14T05:00:00Z'
  },
  {
    id: 'notif_2',
    roleTarget: 'citizen',
    complaintId: 'CB-2026-0972',
    title: 'Streetlight Complaint Resolved!',
    message: 'Your report regarding broken streetlight on Nehru Ring Road has been inspected and resolved with proof of completion.',
    type: 'status_update',
    isRead: false,
    createdAt: '2026-10-13T20:45:00Z'
  },
  {
    id: 'notif_3',
    roleTarget: 'official',
    complaintId: 'CB-2026-1042',
    title: 'New Assignment: Pothole Urgent',
    message: 'Pothole complaint CB-2026-1042 assigned to Ward 101 Inspector Vikram Patel.',
    type: 'assignment',
    isRead: true,
    createdAt: '2026-10-12T15:05:00Z'
  }
];
