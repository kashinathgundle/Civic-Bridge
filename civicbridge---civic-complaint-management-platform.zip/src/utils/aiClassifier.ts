import { AiSuggestion, Priority } from '../types';

interface CategoryRule {
  categoryId: string;
  categoryName: string;
  defaultPriority: Priority;
  keywords: string[];
  highUrgencyKeywords: string[];
  patterns: RegExp[];
}

const CATEGORY_RULES: CategoryRule[] = [
  {
    categoryId: 'cat_potholes',
    categoryName: 'Potholes & Damaged Roads',
    defaultPriority: 'medium',
    keywords: [
      'pothole', 'potholes', 'crater', 'road', 'asphalt', 'tar', 'damaged road',
      'broken road', 'uneven road', 'tarmac', 'ditch', 'speed breaker', 'cave in',
      'sinkhole', 'bump', 'pavement broken', 'resurfacing', 'cracks'
    ],
    highUrgencyKeywords: ['accident', 'severe accident', 'deep crater', 'cave in', 'sinkhole', 'hazardous', 'bus stuck', 'highway'],
    patterns: [/pot[\s-]?hole/i, /damaged\s+road/i, /deep\s+crater/i, /broken\s+asphalt/i, /sink[\s-]?hole/i]
  },
  {
    categoryId: 'cat_garbage',
    categoryName: 'Garbage & Solid Waste',
    defaultPriority: 'medium',
    keywords: [
      'garbage', 'trash', 'waste', 'dump', 'dustbin', 'litter', 'overflowing bin',
      'plastic waste', 'debris', 'filth', 'rotten', 'stinking', 'foul smell',
      'garbage truck', 'refuse', 'rubbish', 'scrap', 'dump yard', 'black spots'
    ],
    highUrgencyKeywords: ['toxic', 'burning garbage', 'medical waste', 'disease', 'hospital gate', 'maggots', 'dead animal'],
    patterns: [/garba?ge/i, /waste\s+dump/i, /overflowing\s+bin/i, /trash\s+pile/i, /littering/i]
  },
  {
    categoryId: 'cat_water',
    categoryName: 'Water Supply & Leakage',
    defaultPriority: 'high',
    keywords: [
      'water', 'pipe', 'pipeline', 'leakage', 'leaking', 'burst pipe', 'gushing water',
      'no water', 'dirty water', 'contaminated water', 'water supply', 'tap', 'meter',
      'valve', 'drinking water', 'low pressure', 'water shortage', 'mainline'
    ],
    highUrgencyKeywords: ['burst pipe', 'flooding street', 'contaminated water', 'gushing', 'hospital supply', 'potable water waste'],
    patterns: [/water\s+leak/i, /pipe\s+burst/i, /no\s+water\s+supply/i, /pipeline\s+damage/i, /dirty\s+tap\s+water/i]
  },
  {
    categoryId: 'cat_drainage',
    categoryName: 'Drainage & Sewage',
    defaultPriority: 'high',
    keywords: [
      'drainage', 'drain', 'sewage', 'gutter', 'manhole', 'open manhole', 'clogged drain',
      'choked gutter', 'overflowing sewage', 'sewer', 'stormwater', 'dirty runoff',
      'stagnant water', 'mosquitoes', 'backflow', 'sludge'
    ],
    highUrgencyKeywords: ['open manhole', 'uncovered manhole', 'drowning risk', 'sewage entering house', 'flooded road', 'dengue risk'],
    patterns: [/open\s+manhole/i, /sewage\s+overflow/i, /drainage\s+clog/i, /choked\s+drain/i, /gutter\s+overflow/i]
  },
  {
    categoryId: 'cat_streetlights',
    categoryName: 'Streetlights & Electrical',
    defaultPriority: 'medium',
    keywords: [
      'streetlight', 'street light', 'lamp post', 'light pole', 'dark road', 'no light',
      'flickering', 'bulb fused', 'blackout', 'short circuit', 'hanging wire',
      'live wire', 'transformer', 'pole tilted', 'junction box'
    ],
    highUrgencyKeywords: ['live wire', 'sparking', 'short circuit', 'hanging wire', 'danger of electrocution', 'complete darkness near school'],
    patterns: [/street[\s-]?light/i, /lamp[\s-]?post/i, /electric\s+pole/i, /hanging\s+wire/i, /live\s+wire/i, /flickering\s+bulb/i]
  },
  {
    categoryId: 'cat_sanitation',
    categoryName: 'Sanitation & Public Health',
    defaultPriority: 'medium',
    keywords: [
      'sanitation', 'public toilet', 'urinal', 'stagnant water', 'mosquito', 'hygiene',
      'dead animal', 'carcass', 'cleaning', 'sweep', 'disinfection', 'spray', 'fogging',
      'foul odor', 'unhygienic'
    ],
    highUrgencyKeywords: ['dead animal', 'epidemic', 'foul carcass', 'infectious', 'hospital vicinity'],
    patterns: [/public\s+toilet/i, /dead\s+animal/i, /mosquito\s+fogging/i, /unhygienic/i]
  },
  {
    categoryId: 'cat_parks',
    categoryName: 'Parks & Fallen Trees',
    defaultPriority: 'low',
    keywords: [
      'tree', 'fallen tree', 'branch', 'tree cutting', 'park', 'playground', 'swing broken',
      'garden', 'grass', 'overgrown', 'horticulture', 'pruning', 'green belt'
    ],
    highUrgencyKeywords: ['tree fell on road', 'blocking traffic', 'fell on wire', 'crushed car', 'imminent collapse'],
    patterns: [/fallen\s+tree/i, /broken\s+branch/i, /park\s+maintenance/i, /tree\s+blocking/i]
  },
  {
    categoryId: 'cat_traffic',
    categoryName: 'Traffic & Encroachment',
    defaultPriority: 'medium',
    keywords: [
      'traffic', 'signal', 'traffic light', 'pedestrian', 'zebra crossing', 'footpath',
      'sidewalk', 'encroachment', 'illegal hawkers', 'blocked footpath', 'signboard missing',
      'divider broken', 'illegal parking'
    ],
    highUrgencyKeywords: ['signal not working at junction', 'blatant danger', 'traffic gridlock', 'school crossing'],
    patterns: [/traffic\s+signal/i, /footpath\s+encroachment/i, /illegal\s+hawker/i, /broken\s+signal/i]
  }
];

const CRITICAL_GLOBAL_KEYWORDS = [
  'urgent', 'emergency', 'danger', 'hazard', 'hazardous', 'risk of death', 'fatal',
  'accident', 'immediate action', 'critical', 'injury', 'severe injury', 'live electric wire',
  'open manhole', 'gushing supply', 'flooding home'
];

/**
 * Free rule-based NLP Classifier that runs 100% locally in the browser or Node.js runtime.
 * Analyzes civic complaint text to predict category, confidence score, priority level,
 * and extracts matching tokens for transparent explainable AI.
 */
export function classifyCivicComplaint(title: string, description: string): AiSuggestion {
  const combinedText = `${title} ${description}`.toLowerCase();
  
  // Tokenize words (remove punctuation)
  const tokens = combinedText
    .replace(/[^\w\s-]/g, ' ')
    .split(/\s+/)
    .filter(token => token.length > 2);

  let bestScore = 0;
  let bestRule = CATEGORY_RULES[0];
  let bestMatchedKeywords: string[] = [];
  let isHighUrgencyDetected = false;

  for (const rule of CATEGORY_RULES) {
    let score = 0;
    const matches: string[] = [];

    // Check regex pattern bonuses (high signal)
    for (const pattern of rule.patterns) {
      if (pattern.test(combinedText)) {
        score += 35;
      }
    }

    // Check keyword hits
    for (const kw of rule.keywords) {
      if (kw.includes(' ')) {
        // Multi-word phrase check
        if (combinedText.includes(kw)) {
          score += 25;
          matches.push(kw);
        }
      } else {
        // Single word hit
        if (tokens.includes(kw)) {
          score += 15;
          matches.push(kw);
        }
      }
    }

    // Check urgency indicators specific to this category
    for (const urgentKw of rule.highUrgencyKeywords) {
      if (combinedText.includes(urgentKw)) {
        score += 20;
        isHighUrgencyDetected = true;
        if (!matches.includes(urgentKw)) {
          matches.push(urgentKw);
        }
      }
    }

    if (score > bestScore) {
      bestScore = score;
      bestRule = rule;
      bestMatchedKeywords = matches;
    }
  }

  // Check global critical keywords for priority escalation
  const globalUrgentHits = CRITICAL_GLOBAL_KEYWORDS.filter(kw => combinedText.includes(kw));
  if (globalUrgentHits.length > 0) {
    isHighUrgencyDetected = true;
    for (const hit of globalUrgentHits) {
      if (!bestMatchedKeywords.includes(hit)) {
        bestMatchedKeywords.push(hit);
      }
    }
  }

  // Calculate normalized confidence percentage (between 0.55 and 0.96)
  let confidence = 0.55;
  if (bestScore > 0) {
    confidence = Math.min(0.97, 0.50 + Math.min(bestScore, 100) * 0.0047);
  }

  // Calculate priority suggestion
  let suggestedPriority: Priority = bestRule.defaultPriority;
  if (isHighUrgencyDetected || globalUrgentHits.length >= 2) {
    suggestedPriority = 'critical';
  } else if (globalUrgentHits.length === 1 && suggestedPriority !== 'critical') {
    suggestedPriority = 'high';
  }

  const keywordSummary = bestMatchedKeywords.slice(0, 4).join(', ');
  const reasoning = bestMatchedKeywords.length > 0
    ? `Identified key civic indicators [${keywordSummary}] matching ${bestRule.categoryName} with ${Math.round(confidence * 100)}% rule confidence.`
    : `General municipal inquiry based on context analysis. Defaulted to ${bestRule.categoryName}.`;

  return {
    categoryId: bestRule.categoryId,
    categoryName: bestRule.categoryName,
    confidence: Math.round(confidence * 100) / 100,
    suggestedPriority,
    matchedKeywords: bestMatchedKeywords.slice(0, 5),
    reasoning,
    engine: 'local_rule_nlp'
  };
}
