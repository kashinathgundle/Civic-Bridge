import React, { useState, useEffect } from 'react';
import {
  Category,
  Complaint,
  DashboardStats,
  Department,
  NotificationItem,
  Role,
  User,
  Ward
} from './types';
import { storage } from './services/storageService';
import { DEMO_USERS } from './data/seedData';
import { Navbar } from './components/layout/Navbar';
import { HomeOverview } from './components/home/HomeOverview';
import { ComplaintForm } from './components/citizen/ComplaintForm';
import { ComplaintTracker } from './components/citizen/ComplaintTracker';
import { OfficialDashboard } from './components/official/OfficialDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { ComplaintDetailModal } from './components/common/ComplaintDetailModal';
import { UpdateStatusModal } from './components/official/UpdateStatusModal';
import { AuthModal } from './components/auth/AuthModal';
import { ProjectGuideModal } from './components/common/ProjectGuideModal';
import {
  ShieldCheck,
  CheckCircle2,
  FileSpreadsheet,
  Download,
  Heart
} from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User>(storage.getCurrentUser());
  const [complaints, setComplaints] = useState<Complaint[]>(storage.getComplaints());
  const [categories, setCategories] = useState<Category[]>(storage.getCategories());
  const [wards, setWards] = useState<Ward[]>(storage.getWards());
  const [departments, setDepartments] = useState<Department[]>(storage.getDepartments());
  const [users, setUsers] = useState<User[]>(storage.getUsers());
  const [notifications, setNotifications] = useState<NotificationItem[]>(
    storage.getNotifications(currentUser.role, currentUser.id)
  );
  const [stats, setStats] = useState<DashboardStats>(storage.getStats());

  const [activeTab, setActiveTab] = useState<'home' | 'submit' | 'track' | 'official' | 'admin' | 'guide'>('home');
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [complaintForUpdate, setComplaintForUpdate] = useState<Complaint | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [trackerSearchQuery, setTrackerSearchQuery] = useState('');
  const [successToast, setSuccessToast] = useState<{ id: string; title: string } | null>(null);

  // Sync state whenever data updates
  const refreshAll = () => {
    setComplaints(storage.getComplaints());
    setCategories(storage.getCategories());
    setWards(storage.getWards());
    setDepartments(storage.getDepartments());
    setUsers(storage.getUsers());
    setStats(storage.getStats());
    const user = storage.getCurrentUser();
    setCurrentUser(user);
    setNotifications(storage.getNotifications(user.role, user.id));
  };

  useEffect(() => {
    refreshAll();
  }, []);

  // Quick switch role
  const handleSwitchUser = (role: Role) => {
    const demo = DEMO_USERS.find(u => u.role === role) || DEMO_USERS[0];
    storage.setCurrentUser(demo);
    setCurrentUser(demo);
    setNotifications(storage.getNotifications(demo.role, demo.id));

    if (role === 'official') {
      setActiveTab('official');
    } else if (role === 'admin') {
      setActiveTab('admin');
    } else {
      setActiveTab('track');
    }
  };

  const handleComplaintSubmitted = (created: Complaint) => {
    refreshAll();
    setSelectedComplaint(created);
    setSuccessToast({ id: created.id, title: created.title });
    setActiveTab('track');
    setTimeout(() => setSuccessToast(null), 6000);
  };

  const handleComplaintUpdated = (updated: Complaint) => {
    refreshAll();
    setSelectedComplaint(updated);
  };

  const handleSelectComplaintId = (id: string) => {
    const found = storage.getComplaintById(id);
    if (found) {
      setSelectedComplaint(found);
    } else {
      setTrackerSearchQuery(id);
      setActiveTab('track');
    }
  };

  const handleMarkNotificationsRead = () => {
    storage.markAllNotificationsAsRead();
    setNotifications(storage.getNotifications(currentUser.role, currentUser.id));
  };

  const handleExportCsv = () => {
    storage.exportComplaintsToCsv();
  };

  const handleExportZip = async () => {
    await storage.exportProjectZip();
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 font-sans flex flex-col selection:bg-cyan-200 selection:text-slate-900">
      {/* Top Navbar */}
      <Navbar
        currentUser={currentUser}
        onSwitchUser={handleSwitchUser}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onLogout={() => {
          storage.resetAllToSeed();
          refreshAll();
        }}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        notifications={notifications}
        onMarkNotificationsRead={handleMarkNotificationsRead}
        onSelectComplaintId={handleSelectComplaintId}
        onExportCsv={handleExportCsv}
        onExportZip={handleExportZip}
      />

      {/* Floating Success Toast */}
      {successToast && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-2xl bg-slate-900 text-white shadow-2xl border border-sky-500/40 flex items-start gap-3 animate-in slide-in-from-bottom duration-300 max-w-sm">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <span className="font-mono text-xs font-bold text-cyan-300 block">
              Registered ID: {successToast.id}
            </span>
            <p className="text-xs font-semibold text-slate-100 line-clamp-1">
              {successToast.title}
            </p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Grievance dispatched to ward authority.
            </p>
          </div>
        </div>
      )}

      {/* Main Content View Switcher */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <HomeOverview
            currentUser={currentUser}
            stats={stats}
            categories={categories}
            recentComplaints={complaints}
            onNavigateSubmit={() => setActiveTab('submit')}
            onNavigateTrack={(query) => {
              if (query) setTrackerSearchQuery(query);
              setActiveTab('track');
            }}
            onSelectComplaint={(c) => setSelectedComplaint(c)}
            onExportCsv={handleExportCsv}
          />
        )}

        {activeTab === 'submit' && (
          <ComplaintForm
            currentUser={currentUser}
            categories={categories}
            wards={wards}
            onComplaintSubmitted={handleComplaintSubmitted}
            onCancel={() => setActiveTab('track')}
          />
        )}

        {activeTab === 'track' && (
          <ComplaintTracker
            complaints={complaints}
            categories={categories}
            currentUser={currentUser}
            onSelectComplaint={(c) => setSelectedComplaint(c)}
            initialSearchQuery={trackerSearchQuery}
            onNewComplaintClick={() => setActiveTab('submit')}
          />
        )}

        {activeTab === 'official' && (
          <OfficialDashboard
            currentUser={currentUser}
            complaints={complaints}
            departments={departments}
            wards={wards}
            onOpenUpdateModal={(c) => setComplaintForUpdate(c)}
            onSelectComplaint={(c) => setSelectedComplaint(c)}
          />
        )}

        {activeTab === 'admin' && (
          <AdminDashboard
            currentUser={currentUser}
            stats={stats}
            complaints={complaints}
            users={users}
            departments={departments}
            wards={wards}
            categories={categories}
            onRefreshData={refreshAll}
            onSelectComplaint={(c) => setSelectedComplaint(c)}
            onExportCsv={handleExportCsv}
            onExportZip={handleExportZip}
          />
        )}

        {activeTab === 'guide' && (
          <ProjectGuideModal
            onExportCsv={handleExportCsv}
            onExportZip={handleExportZip}
          />
        )}
      </main>

      {/* Complaint Detail Modal */}
      <ComplaintDetailModal
        complaint={selectedComplaint}
        currentUser={currentUser}
        onClose={() => setSelectedComplaint(null)}
        onUpdateStatusClick={(c) => setComplaintForUpdate(c)}
        onRefreshComplaint={handleComplaintUpdated}
      />

      {/* Update Status Modal */}
      <UpdateStatusModal
        complaint={complaintForUpdate}
        currentUser={currentUser}
        isOpen={!!complaintForUpdate}
        onClose={() => setComplaintForUpdate(null)}
        onUpdated={handleComplaintUpdated}
      />

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onSuccess={(u) => {
          setCurrentUser(u);
          refreshAll();
        }}
        wards={wards}
      />

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 text-xs py-8 px-4 sm:px-6 lg:px-8 border-t border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-sky-600 text-white flex items-center justify-center font-bold text-xs">
              CB
            </div>
            <span className="font-bold text-white">CivicBridge</span>
            <span className="text-slate-500">&bull; College Capstone Project Edition</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <button onClick={() => setActiveTab('guide')} className="hover:text-cyan-300">
              Architecture Guide
            </button>
            <button onClick={handleExportCsv} className="hover:text-cyan-300">
              Export CSV
            </button>
            <button onClick={handleExportZip} className="hover:text-cyan-300">
              Export Source Code ZIP
            </button>
            <span className="text-slate-500">100% Free Open-Source</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
