# CivicBridge - AI-Powered Civic Complaint Management Platform

**CivicBridge** is a modern, responsive, open-source civic grievance redresal and tracking system built for academic engineering capstone projects. It connects citizens directly with municipal ward inspectors and city administrators, ensuring transparent, accountable, and speedy public infrastructure repairs.

---

## 🌟 Key Highlights & Zero-Cost Architecture

- **100% Free Operation**: Does not require any paid subscription, paid API key (no Gemini API billing, no Google Maps API billing, no WhatsApp business API billing, and no paid hosting).
- **Autonomous Local AI Classifier**: Uses an in-memory rule-based Natural Language Processing classifier that detects municipal categories, extracts civic hazard indicators, and scores emergency urgency with 0 external API calls and 0 latency.
- **Free OpenStreetMap & Leaflet Integration**: Fully interactive map picker with draggable coordinate pins, address suggestions, and multi-marker GIS city overview.
- **Three Core User Roles**:
  - **Citizen**: File complaints with photo proof and geo-coordinates, track live step-by-step progress, view complete audit timelines, and rate repair quality.
  - **Municipal Official**: Filter ward grievances, assign field crews (e.g. *Rapid Asphalt Paving Crew #3*), update stages (*Under Review -> Assigned -> In Progress -> Resolved*), and attach proof of resolution photos.
  - **City Administrator**: Monitor real-time KPIs (Total Grievances, Resolution Rate %, Average SLA turnaround), manage departments and categories, assign user roles, and export municipal CSV reports.
- **Complete Audit Trail**: Every status transition logs the actor name, role, timestamp, and official remarks.
- **Exportable Deliverables**:
  - Download standard municipal complaint reports as **CSV**
  - Download complete source code package as a **ZIP** file from within the app

---

## 📋 Pre-Configured Test Accounts

| Role | Name | Email | Password | Scope & Responsibilities |
| :--- | :--- | :--- | :--- | :--- |
| **Citizen** | Aarav Sharma | `citizen@civicbridge.org` | `demo123` | File complaints, track status, submit ratings |
| **Official** | Inspector Vikram Patel | `official@civicbridge.org` | `demo123` | Roads & Infra Dept, Ward 101, Crew dispatch |
| **Administrator** | Director Sunita Rao | `admin@civicbridge.org` | `demo123` | Citywide analytics, User management, CSV exports |

> *Tip: You can switch between these roles in 1 click using the top banner "Quick Switch Demo" buttons!*

---

## 🛠 Tech Stack

- **Frontend**: React 19 + TypeScript + Vite
- **Styling**: Tailwind CSS v4 with custom municipal cyan/navy palette
- **Mapping**: Leaflet 1.9 + OpenStreetMap (Attribution Compliant)
- **Icons & Motion**: Lucide React + Motion
- **AI Classification**: Autonomous in-browser rule-based NLP Classifier (`src/utils/aiClassifier.ts`)
- **Persistence**: High-performance client-side storage engine with JSON backup/restore & seed data initialization
- **Data Packaging**: JSZip + standard CSV generator

---

## 💻 How to Run on Your Personal Computer (100% Free)

### Prerequisites:
- **Node.js** (Version 18.0 or higher recommended). Download for free from [nodejs.org](https://nodejs.org).
- **npm** (comes bundled automatically with Node.js).

### Step 1: Download and Extract
Download the project ZIP from the app (or clone the repository) and extract it to a folder on your computer.

### Step 2: Open Terminal / Command Prompt
Open your terminal in the extracted folder:
```bash
cd civicbridge
```

### Step 3: Install Dependencies
Run the command below to install all free, open-source packages:
```bash
npm install
```

### Step 4: Start the Local Development Server
```bash
npm run dev
```

### Step 5: Open in Your Browser
Open your browser and navigate to:
```
http://localhost:3000
```
The application will launch immediately with full functionality, demo data, and interactive maps!

---

## 🔍 Distinction: Working Features vs. Optional External Services

| Feature | Current Working Implementation (Free) | Optional Enterprise Production Upgrade |
| :--- | :--- | :--- |
| **AI Category & Urgency Suggestion** | **Active & Autonomous**: Local NLP rule-based classifier evaluating title + description tokens with confidence scoring. | Cloud LLM (Gemini 2.5 Flash) via server-side API proxy when API key is provided. |
| **Geographic Map & Location Picker** | **Active & Free**: Leaflet + OpenStreetMap tiles with GPS location finder & reverse-geocoding. | Google Maps JavaScript API (requires Google Cloud billing/credit card). |
| **Data Storage & Persistence** | **Active**: Structured in-browser persistent database with JSON backup and instant 1-click reset. | PostgreSQL / SQLite relational database via Express REST API (`/api/complaints`). |
| **Notifications** | **Active**: In-app real-time notification drawer with unread counters. | WhatsApp Business API / Twilio SMS (requires paid vendor subscription). |
| **Reports** | **Active**: Real-time downloadable CSV audit spreadsheets. | Scheduled automated email delivery via SendGrid. |

---

## 📁 Project Structure

```
civicbridge/
├── index.html                   # HTML entry point with Leaflet styling
├── package.json                 # Project dependencies & scripts
├── tsconfig.json                # TypeScript compiler configuration
├── vite.config.ts               # Vite configuration with Tailwind CSS v4
├── README.md                    # Academic project documentation & setup
├── src/
│   ├── main.tsx                 # React DOM mount point
│   ├── index.css                # Global Tailwind CSS styles
│   ├── App.tsx                  # Root controller & view router
│   ├── types/
│   │   └── index.ts             # TypeScript domain interfaces
│   ├── data/
│   │   └── seedData.ts          # Seed data (Departments, Wards, Complaints, Users)
│   ├── utils/
│   │   └── aiClassifier.ts      # Autonomous free local AI NLP classifier
│   ├── services/
│   │   └── storageService.ts    # Persistent storage engine, CSV & ZIP exporter
│   └── components/
│       ├── layout/
│       │   └── Navbar.tsx       # Navigation bar & quick demo role switcher
│       ├── home/
│       │   └── HomeOverview.tsx # Landing overview, KPI counters & workflow
│       ├── citizen/
│       │   ├── ComplaintForm.tsx    # Issue filing form with AI suggestions & Leaflet picker
│       │   └── ComplaintTracker.tsx # Grievance registry with filters, cards & map view
│       ├── official/
│       │   ├── OfficialDashboard.tsx # Inspector desk for crew assignments
│       │   └── UpdateStatusModal.tsx # Status transition modal with proof photo upload
│       ├── admin/
│       │   └── AdminDashboard.tsx    # Central administration & analytics
│       └── common/
│           ├── LeafletMap.tsx        # OpenStreetMap & Leaflet mapping component
│           ├── ComplaintDetailModal.tsx # Full complaint audit timeline & before/after view
│           └── ProjectGuideModal.tsx # Academic viva/presentation guide
```

---

## 📜 License & College Project Disclaimer

This project is released under the **Apache 2.0 License** for academic and educational evaluation. All sample complaints and official names are purely fictional representations created for demonstration purposes.
