/**
 * Optional Standalone Express Backend for CivicBridge
 * 
 * To run this standalone backend server:
 *   node server/standalone-server.js
 * 
 * It runs on port 5000 and provides REST endpoints for civic complaints,
 * statistics, status updates, and CSV audit exports.
 */

import express from 'express';
import fs from 'fs';
import path from 'path';

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json({ limit: '15mb' }));

// Simple in-memory / JSON file persistence
const DB_FILE = path.join(process.cwd(), 'civicbridge-server-data.json');

function loadData() {
  if (fs.existsSync(DB_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    } catch (e) {
      console.error('Error reading database file:', e);
    }
  }
  return {
    complaints: [],
    users: [],
    lastUpdated: new Date().toISOString()
  };
}

function saveData(data) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf8');
  } catch (e) {
    console.error('Error writing database file:', e);
  }
}

let db = loadData();

// Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    platform: 'CivicBridge Standalone Node.js Backend',
    uptime: process.uptime(),
    timestamp: new Date().toISOString()
  });
});

// GET /api/complaints
app.get('/api/complaints', (req, res) => {
  const { status, category, priority, ward } = req.query;
  let results = db.complaints;

  if (status && status !== 'all') {
    results = results.filter(c => c.status === status);
  }
  if (category && category !== 'all') {
    results = results.filter(c => c.categoryId === category);
  }
  if (priority && priority !== 'all') {
    results = results.filter(c => c.priority === priority);
  }
  if (ward && ward !== 'all') {
    results = results.filter(c => c.wardId === ward);
  }

  res.json(results);
});

// GET /api/complaints/:id
app.get('/api/complaints/:id', (req, res) => {
  const item = db.complaints.find(c => c.id === req.params.id);
  if (!item) {
    return res.status(404).json({ error: 'Complaint not found' });
  }
  res.json(item);
});

// POST /api/complaints
app.post('/api/complaints', (req, res) => {
  const newComplaint = {
    ...req.body,
    id: `CB-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  db.complaints.unshift(newComplaint);
  saveData(db);
  res.status(201).json(newComplaint);
});

// PUT /api/complaints/:id/status
app.put('/api/complaints/:id/status', (req, res) => {
  const idx = db.complaints.findIndex(c => c.id === req.params.id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Complaint not found' });
  }

  const { status, remarks, actorName, actorRole, assignedTeam, resolutionPhoto } = req.body;
  const complaint = db.complaints[idx];
  const now = new Date().toISOString();

  complaint.status = status || complaint.status;
  complaint.updatedAt = now;
  if (remarks) complaint.officialRemarks = remarks;
  if (assignedTeam) complaint.assignedTeam = assignedTeam;
  if (resolutionPhoto) complaint.resolutionPhoto = resolutionPhoto;

  if (!complaint.timeline) complaint.timeline = [];
  complaint.timeline.push({
    id: `tl_${Date.now()}`,
    status,
    title: `Status changed to ${status}`,
    actorName: actorName || 'Municipal Inspector',
    actorRole: actorRole || 'official',
    timestamp: now,
    remarks
  });

  saveData(db);
  res.json(complaint);
});

// GET /api/stats
app.get('/api/stats', (req, res) => {
  const total = db.complaints.length;
  const resolved = db.complaints.filter(c => c.status === 'resolved').length;
  res.json({
    total,
    resolved,
    inProgress: db.complaints.filter(c => c.status === 'in_progress').length,
    underReview: db.complaints.filter(c => c.status === 'under_review').length,
    resolutionRate: total > 0 ? Math.round((resolved / total) * 100) : 0
  });
});

app.listen(PORT, () => {
  console.log(`[CivicBridge Backend] Server running on http://localhost:${PORT}`);
});
